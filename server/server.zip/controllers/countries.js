
/**
 * Created by sotelo on 06/04/2017.
 */
var util = require('../nutjs/util/util');
var DataModel = require('../nutjs/util/datamodel');
var model = require('../models/Country');
var adapter = util.getAdapter(model);

var authorization = require('../nutjs/security/authorization');
var Promise = require("bluebird");
var logger = require("../config/logger");

var app = require('../server');
var env = require("../config/env");
var mode = app.get('env');
var secret = require('../config/secret');
var jwt = require('jsonwebtoken');


exports.find = {};
exports.find.verb = 'get';
exports.find.path = '/server/api/countries';
exports.find.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    reqParams.where = (reqParams.where?JSON.parse(reqParams.where):{});

    var parameters = adapter.validateFind(reqParams, model);
    adapter.find(parameters).then(function (response) {
        res.json(response);
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};


exports.findOne = {};
exports.findOne.verb = 'get';
exports.findOne.path = '/server/api/country';
exports.findOne.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    //if (util.customAccessGranted(reqParams.where, authData.data.companies, 'id', 'company_id', res)) {
        var parameters = adapter.validateFindOne(reqParams, model);
        var datamodel = new DataModel();
        adapter.findOne(parameters).then(function (response) {
            res.json(response);
        }).catch(function (err) {
            logger.error(err);
            var datamodelErr = adapter.handleError(err);
            res.json(datamodelErr);
        });
    //}
    ;
};


exports.save = {};
exports.save.verb = 'post';
exports.save.path = '/server/api/countries';
exports.save.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;

    var reqBodyParams = req.body;
    var parameters = adapter.validateSave(reqBodyParams, model);
    adapter.transaction(function (client) {
        var datamodel = new DataModel();
        if (reqBodyParams.data.hasOwnProperty(model.pk)) {
            return adapter.updateT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        } else {
            return adapter.insertT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        }
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.saveOne = {};
exports.saveOne.verb = 'post';
exports.saveOne.path = '/server/api/country';
exports.saveOne.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;
    var reqBodyParams = req.body;

    adapter.transaction(function (client) {
        return adapter.saveOneT(reqBodyParams, model, client).then(function (result){
            var datamodel = new DataModel();
            datamodel.code = 200;
            datamodel.result = result.result.data;
            res.json(datamodel)
        });

    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.delete = {};
exports.delete.verb = 'delete';
exports.delete.path = '/server/api/country';
exports.delete.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;

    var reqParams = util.extractReqParams(req);
    var parameters = adapter.validateDelete(reqParams, model);

    adapter.transaction(function (client) {
        var datamodel = new DataModel();
        var speaker_id = parameters.where.id;
        var deleteSpeakerParams = {where:{speaker_id:JSON.parse(parameters.where).id}};
        deleteSpeakerParams = adapter.validateDelete(deleteSpeakerParams, modelLang);
        adapter.deleteT(parameters, client).then(function (result){
            return result;
        }).then(function () {
            return adapter.deleteT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        });
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.countriesByContinent = {};
exports.countriesByContinent.verb = 'get';
exports.countriesByContinent.path = '/server/api/countries/bycontinent';
exports.countriesByContinent.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    reqParams.where = (reqParams.where?JSON.parse(reqParams.where):{});

    var parameters = adapter.validateFind(reqParams, model);
    adapter.find(parameters).then(function (response) {
        let result = [];
        let continent_id = -1;
        let countries = response.result.data;
        let countryList = [];
        for(let i = 0; i<countries.length; i++){
          // console.log(countries[i].continent_id);
          if(countries[i].continent_id!=continent_id){
            continent_id = countries[i].continent_id;

            countryList = [];
            result.push({
                          continent_id: countries[i].continent_id,
                          continent_name: countries[i].continent_name,
                          countryList: countryList
                        });
          }

          countryList.push({
            id: countries[i].id,
            name: countries[i].name_es,
            gl: countries[i].name_gl,
            es: countries[i].name_es,
            en: countries[i].name_en
          });
        }

        let dataModel = new DataModel();
        dataModel.code = 200;
        dataModel.result = result;

        res.json(dataModel);
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

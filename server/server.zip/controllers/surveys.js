
/**
 * Created by sotelo on 06/04/2017.
 */
var util = require('../nutjs/util/util');
var DataModel = require('../nutjs/util/datamodel');
var model = require('../models/Survey');
var adapter = util.getAdapter(model);

var exporter = require('../nutjs/util/exporter');

var authorization = require('../nutjs/security/authorization');
var Promise = require("bluebird");
var logger = require("../config/logger");

var app = require('../server');
var env = require("../config/env");
var mode = app.get('env');
var secret = require('../config/secret');
var jwt = require('jsonwebtoken');


exports.find = {};
exports.find.verb = 'get';
exports.find.path = '/server/api/surveys';
exports.find.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);

    var parameters = adapter.validateFind(reqParams, model);
    adapter.find(parameters).then(function (response) {
        res.json(response);
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

let dbChartQuery = `SELECT v_surveys.$projection_name AS name,  
count(v_surveys.$projection_name) AS num_people, -1 municipality_id   
FROM v_surveys  
WHERE v_surveys.survey_type != 'satisfaction'`;
let dbChartGroupBy = ' GROUP BY v_surveys.$projection_name ';
let dbChartOrderBy = ' ORDER BY v_surveys.$projection_name;';

exports.dbchart = {};
exports.dbchart.verb = 'get';
exports.dbchart.path = '/server/api/dbchart';
exports.dbchart.method = function (req, res) {
    console.log('----------------------------------------------------------');
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    if(!util.isObject(reqParams.where)){
      reqParams.where = JSON.parse(reqParams.where);
    }
    console.log(reqParams);
    let projection = reqParams.projection;

    let query = dbChartQuery.replace('$projection', projection);
    query = query.replace('$projection', projection);
    query+=" AND formatted_survey_date>='"+reqParams.where.initDate+"' ";
    query+=" AND formatted_survey_date<='"+reqParams.where.endDate+"' ";
    if(reqParams.where.municipality_id && reqParams.where.municipality_id.length>0){
      query+=" AND municipality_id in (" + reqParams.where.municipality_id.join(',') + ") ";
    }
    if(reqParams.where.groupTypes && reqParams.where.groupTypes.length>0){
        query+= " AND v_surveys.group_type = ANY(ARRAY[" + reqParams.where.groupTypes.join(',') +"])";
    }
    if(reqParams.where.ages && reqParams.where.ages.length>0){
        query+= "AND (";
        for(let i = 0; i<reqParams.where.ages.length; i++){
            if(i>0){
                query +=  " OR ";
            }
            query+= "v_surveys.age->>'"+reqParams.where.ages[i]+"' is not null "
        }
        query+= ")";
    }
    if(reqParams.where.accommodations && reqParams.where.accommodations.length>0){
        query+= "AND (";
        for(let i = 0; i<reqParams.where.accommodations.length; i++){
            if(i>0){
                query +=  " OR ";
            }
            query += "v_surveys.overnight_accommodation::varchar like " + "'%" + reqParams.where.accommodations[i] +"%'";
        }
        query+= ")";
    }

    query += ' AND '+ projection +'_id is not null';

    if(projection == 'province'){
        query += ' AND province_id in (15, 27, 32, 36) ';
    }

    query+= dbChartGroupBy.replace('$projection', projection);
    query+= dbChartOrderBy.replace('$projection', projection);

    console.log(query);
    getItemsByQuery(model, query).then(function (response) {
        res.json(response);
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.filter = {};
exports.filter.verb = 'get';
exports.filter.path = '/server/api/filtersurveys';
exports.filter.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    if(!util.isObject(reqParams.where)){
      reqParams.where = JSON.parse(reqParams.where);
    }
    var query = "SELECT * FROM " + model.projections[reqParams.projection].from;
    query+=" WHERE survey_type != 'satisfaction' ";
    query+=" AND formatted_survey_date>='"+reqParams.where.initDate+"' ";
    query+=" AND formatted_survey_date<='"+reqParams.where.endDate+"' ";
    if(reqParams.where.municipality_id && reqParams.where.municipality_id.length>0){
      query+=" AND municipality_id in (" + reqParams.where.municipality_id.join(',') + ") ";
    }
    if(reqParams.where.groupTypes && reqParams.where.groupTypes.length>0){
        query+= " AND "+model.projections[reqParams.projection].from + ".group_type = ANY(ARRAY[" + reqParams.where.groupTypes.join(',') +"])";
    }
    if(reqParams.where.ages && reqParams.where.ages.length>0){
        query+= "AND (";
        for(let i = 0; i<reqParams.where.ages.length; i++){
            if(i>0){
                query +=  " OR ";
            }
            query+= model.projections[reqParams.projection].from+".age->>'"+reqParams.where.ages[i]+"' is not null "
        }
        query+= ")";
    }
    if(reqParams.where.accommodations && reqParams.where.accommodations.length>0){
        query+= "AND (";
        for(let i = 0; i<reqParams.where.accommodations.length; i++){
            if(i>0){
                query +=  " OR ";
            }
            query += model.projections[reqParams.projection].from + ".overnight_accommodation::varchar like " + "'%" + reqParams.where.accommodations[i] +"%'";
        }
        query+= ")";
    }
    // console.log(query);
    getItemsByQuery(model, query).then(function (response) {
        //console.log(response);
        res.json(response);
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

function getItemsByQuery(model, query){
  return new Promise ((resolve,reject) => {
    var adapter = util.getAdapter(model);
    var parameters = {
      sql: query,
      values: []
     };
    adapter.execsql(parameters).then(function (response) {
      resolve(response);
    });
  })
}

exports.findOne = {};
exports.findOne.verb = 'get';
exports.findOne.path = '/server/api/survey';
exports.findOne.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    var reqParams = util.extractReqParams(req);
    //if (util.customAccessGranted(reqParams.where, authData.data.companies, 'id', 'company_id', res)) {
        var parameters = adapter.validateFindOne(reqParams, model);
        var datamodel = new DataModel();
        adapter.findOne(parameters).then(function (response) {
            res.json(response);
        }).catch(function (err) {
            logger.error(err);
            var datamodelErr = adapter.handleError(err);
            res.json(datamodelErr);
        });
    //}
    ;
};


exports.save = {};
exports.save.verb = 'post';
exports.save.path = '/server/api/surveys';
exports.save.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;
    var reqBodyParams = (req.body?JSON.parse(req.body):{});

    var parameters = adapter.validateSave(reqBodyParams, model);
    adapter.transaction(function (client) {
        var datamodel = new DataModel();
        if (reqBodyParams.data.hasOwnProperty(model.pk)) {
            return adapter.updateT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        } else {
            return adapter.insertT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        }
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.saveOne = {};
exports.saveOne.verb = 'post';
exports.saveOne.path = '/server/api/survey';
exports.saveOne.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;
    var reqBodyParams = req.body;

    adapter.transaction(function (client) {
        return adapter.saveOneT(reqBodyParams, model, client).then(function (result){
            var datamodel = new DataModel();
            datamodel.code = 200;
            datamodel.result = result.result.data;
            res.json(datamodel)
        });

    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.delete = {};
exports.delete.verb = 'delete';
exports.delete.path = '/server/api/survey';
exports.delete.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;

    var reqParams = util.extractReqParams(req);
    var parameters = adapter.validateDelete(reqParams, model);

    adapter.transaction(function (client) {
        var datamodel = new DataModel();
        var speaker_id = parameters.where.id;
        var deleteSpeakerParams = {where:{speaker_id:JSON.parse(parameters.where).id}};
        deleteSpeakerParams = adapter.validateDelete(deleteSpeakerParams, modelLang);
        adapter.deleteT(parameters, client).then(function (result){
            return result;
        }).then(function () {
            return adapter.deleteT(parameters, client).then(function (result){
                datamodel.code = 200;
                datamodel.result = result[0].rows[0];
                res.json(datamodel)
            });
        });
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};



exports.saveAll = {};
exports.saveAll.verb = 'post';
exports.saveAll.path = '/server/api/surveys/all';
exports.saveAll.method = function (req, res) {
    //var authData = authorization.decodeAuthToken(req, res);
    //var user_id = authData.data.id;

    var reqBodyParams = JSON.parse(req.body);
    var surveys = reqBodyParams.data;
    var terminal_id = reqBodyParams.terminal_id;
    var device_id = reqBodyParams.device_id;
    adapter.transaction(client => {
        var datamodel = new DataModel();
        let promises = [];
        for(let i = 0; i<surveys.length; i++){
            // console.log(surveys[i]);
            surveys[i].age = JSON.stringify(surveys[i].age);
            surveys[i].travel_reason = JSON.stringify(surveys[i].travel_reason);
            surveys[i].overnight_accommodation = JSON.stringify(surveys[i].overnight_accommodation);
            surveys[i].consult_reason = JSON.stringify(surveys[i].consult_reason);
            surveys[i].transport = JSON.stringify(surveys[i].transport);
            surveys[i].terminal_id = terminal_id;
            surveys[i].device_id = device_id;
            // console.log(surveys[i]);
            var parameters = adapter.validateSave({data: surveys[i]}, model);
            promises.push(adapter.insertT(parameters, client));
        }


        return Promise.all(promises).then(values => {
            datamodel.code = 200;
            datamodel.result = values;
            res.json(datamodel)
        });

    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

exports.generateXLSX = {};
exports.generateXLSX.verb = 'get';
exports.generateXLSX.path = '/server/api/surveys/xlsx';
exports.generateXLSX.method = function(req, res) {

    var reqParams = util.extractReqParams(req);

    var parameters = adapter.validateFind(reqParams, model);
    let exportParams = {};
    adapter.find(parameters).then(function (response) {
        exportParams.body = {
            data:response.result.data,
            columns : reqParams.columns,
            title : reqParams.title,
            filename : reqParams.filename
        };
        exporter.xlsx(exportParams, res, function(response){
            util.log(response);
        });
    }).catch(function (err) {
        logger.error(err);
        var datamodelErr = adapter.handleError(err);
        res.json(datamodelErr);
    });
};

var datasource = {
	"adapter": "nutpg",
	"config": {
		"development": {
            "user": "postgres",
            "password": "0c40u70.0218",
            "database": "ochousosoft-knownledge",
            "host": "193.70.90.65",
            "port": 5432
		},
		"production": {
			"user": "postgres",
			"password": "0c40u70.0218",
			"database": "ochousosoft-knownledge",
			"host": "193.70.90.65",
			"port": 5432
		}
	}
};

module.exports = datasource;

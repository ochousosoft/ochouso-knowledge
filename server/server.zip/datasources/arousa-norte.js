var datasource = {
	"adapter": "nutpg",
	"config": {
		"development": {
            "user": "postgres",
            "password": "C0c0d!n@2013",
            "database": "arousa-norte",
            "host": "cocodin.com",
            "port": 5432
		},
		"production": {
			"user": "postgres",
			"password": "ad#432Rx?21PO",
			"database": "arousa-norte",
			"host": "185.129.248.113",
			"port": 5432
		}
	}
};

module.exports = datasource;

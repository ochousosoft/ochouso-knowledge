var model = {
	datasource : 'arousa-norte',	//ref to datasource connection info (postgres datasource defined in /datasources/)
	pk : 'id', //primary key
	table : 'municipalities', //Associated model table
	auto : '',
	columns : {
		id: 'integer',
		name: 'string'
	},
	projections : {
	'default' : {
			find : ['id','name'],
			save : [],
			from : 'municipalities',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		}
    }
};

module.exports = model;

var model = {
	datasource : 'arousa-norte',	//ref to datasource connection info (postgres datasource defined in /datasources/)
	pk : 'id', //primary key
	table : 'countries', //Associated model table
	auto : '',
	columns : {
		id: 'integer',
		cordova: 'string',
		platform: 'string',
		model: 'string',
		uuid:'string',
		version: 'string',
		manufacturer: 'string',
		serial: 'string',
		is_virtual: 'boolean',
		terminal_id: 'integer'
	},
	projections : {
	'default' : {
			find : ['id','name_gl','name_es','name_en', 'continent_name', 'continent_id'],
			save : [],
			from : 'v_countries',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		}
    }
};

module.exports = model;

var model = {
	datasource : 'arousa-norte',	//ref to datasource connection info (postgres datasource defined in /datasources/)
	pk : 'id', //primary key
	table : 'surveys', //Associated model table
	auto : '',
	columns : {
		id					: 'integer',
		terminal_id					: 'integer',
		device_id					: 'integer',
		survey_date	: 'string',
		lang: 'string',
		disability: 'integer',
		origin: 'integer',
		postal_code: 'string',
		first_time: 'integer',
		group_type: 'integer',
		group_number: 'integer',
		age: 'string',
		duration: 'integer',
		travel_reason: 'string',
		overnights: 'integer',
		overnight_accommodation: 'string',
		consult_reason: 'string',
		transport: 'string',
		satisfaction1: 'integer',
		satisfaction2: 'integer',
		satisfaction3: 'integer',
		satisfaction4: 'integer',
		satisfaction5: 'integer',
		satisfaction6: 'integer',
		satisfaction7: 'integer',
		satisfaction8: 'integer',
		satisfaction9: 'integer'
	},
	projections : {
		'default' : {
			find : ['id', 'survey_date','lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9','terminal_id',
							'device_id'],
			save : ['survey_date', 'lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9', 'terminal_id',
							'device_id'],
			from : 'surveys',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'complete' : {
			find : ['id', 'survey_date','lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9','terminal_id',
							'device_id', 'user_name', 'user_type', 'office_id', 'office_name', 'municipality_name', 'creation_date', 'municipality_id', 
							'source', 'survey_type', 'formatted_survey_date'],
			save : [],
			from : 'v_surveys',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'current_surveys' : {
			find : ['id', 'survey_date','lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9','terminal_id',
							'device_id', 'user_name', 'user_type', 'office_id', 'office_name', 'municipality_name', 'creation_date', 'municipality_id', 
							'source', 'survey_type', 'formatted_survey_date'],
			save : [],
			from : 'v_current_surveys',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'satisfaction_surveys' : {
			find : ['id', 'survey_date','lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9','terminal_id',
							'device_id', 'user_name', 'user_type', 'office_id', 'office_name', 'municipality_name', 'creation_date', 'municipality_id', 
							'source', 'survey_type', 'formatted_survey_date'],
			save : [],
			from : 'v_satisfaction_surveys',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'current_surveys' : {
			find : ['id', 'survey_date','lang','disability','origin','postal_code','first_time','group_type','group_number','age','duration',
							'travel_reason','overnights','overnight_accommodation','consult_reason','transport','satisfaction1','satisfaction2',
							'satisfaction3','satisfaction4','satisfaction5','satisfaction6','satisfaction7','satisfaction8','satisfaction9','terminal_id',
							'device_id', 'user_name', 'user_type', 'office_id', 'office_name', 'municipality_name', 'creation_date', 'municipality_id', 
							'source', 'survey_type', 'formatted_survey_date'],
			save : [],
			from : 'v_current_surveys',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'people_by_state' : {
			find : ['id', 'name', 'num_people', 'municipality_id'],
			save : [],
			from : 'v_people_by_state',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'people_by_province' : {
			find : ['id', 'name', 'num_people', 'municipality_id'],
			save : [],
			from : 'v_people_by_province',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		},

		'people_by_country' : {
			find : ['name', 'num_people', 'municipality_id'],
			save : [],
			from : 'v_people_by_country',
			countColumn:'id',
			//TODO accept join in model to avoid creating new views
			join : '',
		}
    },


};

module.exports = model;

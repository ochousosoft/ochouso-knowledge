//App launcher = node server.js development
var mode = process.env.NODE_ENV || 'development';
module.exports = mode;
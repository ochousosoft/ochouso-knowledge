//secret string to create tokens
module.exports = 'cocodin';

/// <reference path="globals/jspdf/index.d.ts" />

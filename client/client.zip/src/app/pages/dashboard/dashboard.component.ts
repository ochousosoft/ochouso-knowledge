import { Component, OnInit, ViewChild, ViewChildren, ElementRef, QueryList, ChangeDetectorRef } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from 'angular-2-dropdown-multiselect';
import * as XLSX from 'xlsx'
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as moment from 'moment';
import * as html2canvas from 'html2canvas';
import { ReportsService } from '../../providers/reports.service';
import { Constants } from  '../../providers/config/constants';
import { AuthenticationService } from '../../providers/index';
import { SurveysService } from '../../providers/rest/surveys.rest.service';
import { Http } from '@angular/http';
import { DialogService } from "ng2-bootstrap-modal";
import { ConfirmComponent } from '../../components/confirm.component/confirm.component';
import { ExportDialogComponent } from '../../components/export-dialog.component/export-dialog.component';

import * as FileSaver from 'file-saver';
import * as htmlDocx from 'html-docx-js/dist/html-docx';

type AOA = any[][];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  isRequesting = false;

  @ViewChildren('canvas') canvas:QueryList<ElementRef>;
  questions = Constants.QUESTIONS;
  // Pie
  public pieChartLabels = {};
  public pieChartData = {}
  public pieChartType:string = 'pie';
  public exporting = false;

  public barChartOptions:any = {
    tooltips:{
      enabled: true
    },
    scales: {
      xAxes: [
       {
           display: true,
           ticks: {
             fontSize: 10,
             autoSkip: false
           }
       }
     ]
   }
  };

  public pieChartOptions:any = {
    tooltips:{
      enabled: true
    }
  };

  tabs = [];
  initTabs(){
    this.tabs = [true, false, false, false, false, false, false, false, false, false, false];
  }
  

  selectTab(index){
    if(!this.exporting){
      for(let i = 0;i<this.tabs.length; i++){
        this.tabs[i] = false;
      }

      this.tabs[index] = true;
    }
  }

  charts =  Constants.CHARTS;


  dropdownSettings = { 
    singleSelection: false, 
    text:"Seleccione item",
    selectAllText:'Seleccionar todo',
    unSelectAllText:'Deseleccionar todo',
    enableSearchFilter: false,
    classes:"bg-success"
  };   

  municipalitiesModel = [];
  municipalitiesOptions = [
    {id:1, itemName: 'A Pobra'},
    {id:2, itemName: 'Boiro'},
    {id:3, itemName: 'Rianxo'},
    {id:4, itemName: 'Riveira'},
    // {id:6, name: 'AVA test'}
  ];


  groupsModel = [];
  groupOptions = [] = [
    {id: 1, itemName: 'Individual' },
    {id: 2, itemName: 'Pareja' },
    {id: 3, itemName: 'Familia' },
    {id: 4, itemName: 'Grupo' }
  ];

  agesModel = [];
  ageOptions = [] = [
    {id: 1, itemName: '0 - 9' },
    {id: 2, itemName: '10 - 19' },
    {id: 3, itemName: '20 - 29' },
    {id: 4, itemName: '30 - 39' },
    {id: 5, itemName: '40 - 49' },
    {id: 6, itemName: '50 - 59' },
    {id: 7, itemName: '60 - 69' },
    {id: 8, itemName: '> 70' }
  ];

  accommodationsModel = [];
  accommodationOptions = [] = [
    {id: 1,  itemName: 'Albergue' },
    {id: 2,  itemName: 'Camping' },
    {id: 3,  itemName: 'Barco' },
    {id: 4,  itemName: 'Caravana' },
    {id: 5,  itemName: 'Casa Fam/Amig/Prop' },
    {id: 6,  itemName: 'Hotel' },
    {id: 7,  itemName: 'Pensión' },
    {id: 8,  itemName: 'Turismo Rural' },
    {id: 9,  itemName: 'Vivienda Alq/Interc' },
    {id: 10, itemName: 'Outros' }
  ];

  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  Auth:any;
  reports: any;
  //debugger
  threemonthAgoDate = moment().subtract('month', 3);
  currentDate = moment();
  filter:any = {
    initDate: { date: { year: this.threemonthAgoDate.get('year'), month: this.threemonthAgoDate.get('month') + 1, day: this.threemonthAgoDate.get('date') } },
    endDate: { date: { year: this.currentDate.get('year'), month: this.currentDate.get('month') + 1, day: this.currentDate.get('date') } }
  
  };

  myTemplate: any;

  public myDatePickerOptions: IMyDpOptions = {
    dateFormat :'dd/mm/yyyy',
  };

  constructor(
    private reportsSrv: ReportsService,
    private authenticationService: AuthenticationService,
    private surveysSrv: SurveysService,
    public detector: ChangeDetectorRef,
    private http: Http,
    private dialogService: DialogService
  ) {
    
    this.initTabs();

    this.Auth = this.authenticationService;
    if(this.authenticationService.isAuthorized('technician')){
      let session = this.authenticationService.getSession();
      this.filter.municipality = session.data.municipality_id;
      //this.filterMem.set(this.filter);
    }

    this.pieChartLabels['duration'] = ['De paso', '1-2 días','3-7 días','8-15 días', '16-30 días', '>30 días'];
    this.pieChartData['duration'] = [0, 0, 0, 0, 0, 0];

    this.pieChartLabels['lang'] = ['Galego', 'Español','Inglés'];
    this.pieChartData['lang'] = [0, 0, 0];

    this.pieChartLabels['age'] = ['0-9', '10-19', '20-29', '30-39', '40-49', '50-59', '60-69', '70+'];
    this.pieChartData['age'] = [0, 0, 0, 0, 0, 0, 0, 0];

    this.pieChartLabels['group_type'] = ['Individual', 'Parella','Familia','Grupo'];
    this.pieChartData['group_type'] = [0, 0, 0, 0];

    this.pieChartLabels['travel_reason'] = ['C. Vida', 'Casa propia','Clima','Cultura','Familia', 'Gastronimía','Medio Natural', 'Praia', 'Outros'];
    this.pieChartData['travel_reason'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    this.pieChartLabels['overnight_accommodation'] = ['Albergue', 'Camping','Barco','Caravana','Casa', 'Hotel', 'Pensión', 'Turismo Rural', 'Aluguer', 'Outros'];
    this.pieChartData['overnight_accommodation'] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    this.pieChartLabels['consult_reason'] = ['Acts Deport.', 'Acts Cultur.','Aloxamentos','C. Santiago','Info', 'Transporte', 'Outros'];
    this.pieChartData['consult_reason'] = [0, 0, 0, 0, 0, 0, 0];

    this.pieChartLabels['transport'] = ['Taxi', 'Vhc. aluguer','Vhc. Propio','Barco','Autobús'];
    this.pieChartData['transport'] = [0, 0, 0, 0, 0];

  }

  drawResultsTable(doc, i, type){
    var columns = [
      {title: "Item", dataKey: "item"},
      {title: "Valor", dataKey: "value"}
    ];
    
    let rows = [];
    for(let j = 0; j<this.pieChartLabels[this.charts[i].key].length;j++){
      let item = this.pieChartLabels[this.charts[i].key][j];
      let value = '';
      if(type==1){
        debugger
        value = this.pieChartData[this.charts[i].key][j];
      }
      else{
        value = this.pieChartData[this.charts[i].key][0].data[j];
      }

      rows.push({
        item: item,
        value: value
      });
    }

    doc.autoTable(columns, rows, {
      theme: 'grid',
      styles: {fillColor: [255, 255, 255]},
      columnStyles: {
        id: {fillColor: 255}
      },
      margin: {top: 10, left: 230}
    });


  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  exportExcelItem(wb, titles, i){
    let rows = [[titles[i].innerText,'']];
    for(let j = 0; j<this.pieChartLabels[this.charts[i].key].length;j++){
      let item = this.pieChartLabels[this.charts[i].key][j];
      let value = '';
      switch(i){
        case 0:
        case 1:
        case 2:
          value = this.pieChartData[this.charts[i].key][0].data[j];
        break;
        default:
          value = this.pieChartData[this.charts[i].key][j];
        break;
      }

      rows.push([
        item,
        value
      ]);
    }

    /* generate worksheet */
		const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(rows);
    
    XLSX.utils.book_append_sheet(wb, ws, titles[i].innerText);
  }

  exportPdfItem(doc, titles, canvases, i, context){
    return new Promise( function(resolve , reject){
      html2canvas(canvases[i])
      .then((canvas) => {
        var img = canvas.toDataURL("image/png");
        doc.text(10, 10, titles[i].innerText);
        switch(i){
          case 0:
          case 1:
          case 2:
          context.drawResultsTable(doc, i, 2);
          doc.addImage(img, 'PNG', 20, 20, 200, 110);
          //
          break;
          default:
          context.drawResultsTable(doc, i, 1);
          doc.addImage(img, 'PNG', 20, 20, 100, 100);
          //

          break;
        }
        resolve();
      })
      .catch(err => {
        console.log("error canvas", err);
        reject();
      });
    });
  }

  getMultiselectValuesText(options, model){
    let text = '';
    if(model){
      let items = [];
      for(let i = 0; i<options.length; i++){
        if(model.indexOf(options[i].id)>=0){
          items.push(options[i].name);
        }
      }
      text = items.join(', ');
    }
    return text;
  }

  async pdfExport(exportList){
    this.exporting = true;

    let doc = new jsPDF('landscape');
    doc.setFontSize(12);
    //doc.addPage();
    // debugger
    let headerImg = document.getElementById('header-img');
    doc.addImage(Constants.BASE64LOGO, 'PNG', 20, 20, 150, 75);
    let initDate = moment(new Date(this.filter.initDate.date.year,this.filter.initDate.date.month-1, this.filter.initDate.date.day)).format('YYYY-MM-DD');
    let endDate = moment(new Date(this.filter.endDate.date.year,this.filter.endDate.date.month-1, this.filter.endDate.date.day)).format('YYYY-MM-DD');
    let initTextVerticalPos = 120;
    let initTextXPos = 20;
    doc.text('INICIO: ' + initDate + '    FIN: ' + endDate, initTextXPos, initTextVerticalPos);
    
    let groupTypes = this.getMultiselectValuesText(this.groupOptions, this.groupsModel);
    if(groupTypes){
      initTextVerticalPos = initTextVerticalPos + 10;
      doc.text('TIPOS GRUPO: ' + groupTypes, initTextXPos, initTextVerticalPos);
    }
    let ages = this.getMultiselectValuesText(this.ageOptions, this.agesModel);
    if(ages){
      initTextVerticalPos = initTextVerticalPos + 10;
      doc.text('RANGOS EDAD: ' + ages, initTextXPos, initTextVerticalPos);
    }
    let accommodations = this.getMultiselectValuesText(this.accommodationOptions, this.accommodationsModel);
    if(accommodations){
      initTextVerticalPos = initTextVerticalPos + 10;
      doc.text('ALOJAMIENTO: ' + accommodations, initTextXPos, initTextVerticalPos);
    }
    let municipalities = this.getMultiselectValuesText(this.municipalitiesOptions, this.municipalitiesModel);
    if(municipalities){
      initTextVerticalPos = initTextVerticalPos + 5;
      doc.text('CONCELLOS: ' + municipalities, initTextXPos, initTextVerticalPos+5);
    }

    doc.addPage();

    let canvases = document.getElementsByTagName('canvas');
    let titles = document.getElementsByTagName('h5');
    debugger
    for(let i = 0; i<exportList.length; i++){
      this.toggleGraphsVisibility(false);
      this.tabs[i] = exportList[i];
      this.detector.detectChanges();
      if(exportList[i]){ 
        await this.sleep(200); 
        await this.exportPdfItem(doc, titles, canvases, i, this);
    
        if(i != canvases.length-1){
          doc.addPage();
        }
      }
    }

    doc.save('Enquisas_' + moment().format('DD-MM-YYYY HH:mm:ss') +  '.pdf');
    this.initTabs();
    this.exporting = false;

  }

  excelExport(exportList){
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();

    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(this.reportsSrv.getSurveys());
    
    XLSX.utils.book_append_sheet(wb, ws, 'Listado enquisas');
    
    let titles = document.getElementsByTagName('h5');
    for(let i = 0; i<exportList.length; i++){
      if(exportList[i]){ 
        this.exportExcelItem(wb, titles, i);
      }
    }
    /* save to file */
		const wbout: ArrayBuffer = XLSX.write(wb, this.wopts);
		FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'Enquisas_' + moment().format('DD-MM-YYYY HH:mm:ss')+ '.xlsx');
  }
  //MIRAR:
  //https://effectiveinc.com/thought-leadership/blogs/generating-downloadable-word-document-browser/
  //http://sebsauvage.net/wiki/doku.php?id=word_document_generation
  public exportWord(){
    debugger
    let imageURL = document.getElementsByTagName('canvas')[0].toDataURL();
    let imageURL1 = document.getElementsByTagName('canvas')[1].toDataURL();
    let imageURL2 = document.getElementsByTagName('canvas')[2].toDataURL();

    var content = "<h1>FFFFFFF</h1>";
    var html_document = '<!DOCTYPE html><html><head><title></title>';
    html_document  += '</head><body>' + content + '</body></html>';

      this.myTemplate = this.myTemplate.replace('{srcImg}', imageURL);
      this.myTemplate = this.myTemplate.replace('{srcImg}', imageURL);
      this.myTemplate = this.myTemplate.replace('{srcImg1}', imageURL1);
      this.myTemplate = this.myTemplate.replace('{srcImg2}', imageURL2);

    let blob = new Blob([this.myTemplate], {
        // type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8"
        type: 'application/vnd.oasis.opendocument.text;charset=utf-8'
    });
    // var blob = htmlDocx.asBlob(this.myTemplate, {orientation: 'landscape'});
    FileSaver.saveAs(blob, "export.odt"); 
  }

  // events
  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }

  loadDBCharts(view){
    return new Promise ((resolve,reject) => {
      let initDate = moment(new Date(this.filter.initDate.date.year,this.filter.initDate.date.month-1, this.filter.initDate.date.day)).format('YYYY-MM-DD');
      let endDate = moment(new Date(this.filter.endDate.date.year,this.filter.endDate.date.month-1, this.filter.endDate.date.day)).format('YYYY-MM-DD');
      debugger
      let groupTypes = this.groupsModel.map(function(elem){
        return elem.id;
      });
      let ages = this.agesModel.map(function(elem){
        return elem.id;
      });
      let accommodations = this.accommodationsModel.map(function(elem){
        return elem.id;
      });
      let municipality_id = this.municipalitiesModel.map(function(elem){
        return elem.id;
      });
      let params = {
        projection: view,
        where: {
          initDate:initDate,
          endDate: endDate,
          municipality_id: municipality_id,
          groupTypes: groupTypes,
          ages: ages,
          accommodations: accommodations
        }
      };
      //debugger
      this.surveysSrv.getDBChart(params)
      .subscribe(data => {
        debugger
        let setName = 'people_by_' + view;
        this.pieChartLabels[setName] = [];
        this.pieChartData[setName] = [{data: [], label: 'Nº persoas'}];
        // debugger
        for(let i = 0; i<data.result.data.length;i++){
          this.pieChartLabels[setName].push(data.result.data[i].name);
          if(this.agesModel.length>0){
            let num_people = 0;
            for(let j = 0; j<this.agesModel.length;j++){
              num_people+= parseInt(data.result.data[i]['num_people_'+this.agesModel[j].id]);
            }
            this.pieChartData[setName][0].data.push(num_people);
          }
          else{
            this.pieChartData[setName][0].data.push(data.result.data[i].num_people);
          }
        }

        resolve();
      }, error => {
        this.isRequesting = false;
        console.log(error)
        reject();
      });
    });
  }

  loadReports(){
    // this.isRequesting = true;
    //debugger
    let initDate = moment(new Date(this.filter.initDate.date.year,this.filter.initDate.date.month-1, this.filter.initDate.date.day)).format('YYYY-MM-DD');
    let endDate = moment(new Date(this.filter.endDate.date.year,this.filter.endDate.date.month-1, this.filter.endDate.date.day)).format('YYYY-MM-DD');
    
    let groupTypes = this.groupsModel.map(function(elem){
      return elem.id;
    });
    let ages = this.agesModel.map(function(elem){
      return elem.id;
    });
    let accommodations = this.accommodationsModel.map(function(elem){
      return elem.id;
    });
    let municipality_id = this.municipalitiesModel.map(function(elem){
      return elem.id;
    })
    debugger
    this.reportsSrv.getReports(municipality_id, initDate, endDate, groupTypes, ages, accommodations).then(result => {
      this.isRequesting = false;
      // debugger
      this.reports = result;

      // debugger
      let items = ['transport', 'consult_reason', 'overnight_accommodation', 'travel_reason'];
      for(let h = 0; h<items.length; h++){
        let keys = Object.keys(this.reports[items[h]]);
        let pieChartData = [];let pieChartLabels = [];
        for(let i = 0; i<keys.length; i++){
          // pieChartLabels.push(keys[i]);
          pieChartData.push(this.reports[items[h]][keys[i]]);
        }

        this.pieChartData[items[h]] = pieChartData;
        // this.pieChartLabels = pieChartLabels;
      }

      this.pieChartData['group_type'] = this.reports['group_type'];
      this.pieChartData['lang'] = this.reports['lang'];
      this.pieChartData['age'] = this.reports['age'];
      this.pieChartData['duration'] = this.reports['duration'];



      this.detector.detectChanges();
    });
  }

  loadData(){
    //debugger
    this.isRequesting = true;
    this.filter.municipality = '';

    this.loadDBCharts('country').then(()=>{
      this.loadDBCharts('state').then(()=>{
        this.loadDBCharts('province').then(()=>{
          //debugger
          this.loadReports();
        });
      });
    });
  }

  ngOnInit() {
    this.loadData();
  }

  downloadCanvas(event, index) {
    // debugger
    // get the `<a>` element from click event
    var anchor = event.target;
    // get the canvas, I'm getting it by tag name, you can do by id
    // and set the href of the anchor to the canvas dataUrl
    anchor.href = document.getElementsByTagName('canvas')[index].toDataURL();
    //let src = document.getElementsByTagName('canvas')[0].toDataURL("image/jpeg", 0.5);

    // set the anchors 'download' attibute (name of the file to be downloaded)
    // debugger
    anchor.download = "graph"+(index+1)+".png";
    // var doc = new jsPDF();
    // doc.addHTML(this.canvas.toArray()[index].nativeElement, ()=>{
    //   doc.save('Test.pdf');
    // });


  }

  onMunicipalityChange(){
    // debugger
    //////////this.filterMem.setValue('municipality', this.filter.municipality);
    //this.loadReports();

  }

  toggleGraphsVisibility(visible){
    for(let i = 0; i<this.tabs.length;i++){
      this.tabs[i] = visible;
    }
    this.detector.detectChanges();
  }

  showConfirm(exportationType) {
    let disposable = this.dialogService.addDialog(ExportDialogComponent, {
        title:'Exportar', 
        message:'Marque los elementos a exportar:'})
        .subscribe((exportList)=>{
            //We get dialog result
            if(exportList) {
              // this.tabs = exportList;
              // this.detector.detectChanges();
              switch(exportationType){
                case 'excel':
                  debugger
                  this.excelExport(exportList); 
                break;
                case 'pdf':
                  this.pdfExport(exportList); 
                break;
              }
              
              
            }
            else {
              this.toggleGraphsVisibility(false);
            }
        });
    //We can close dialog calling disposable.unsubscribe();
    //If dialog was not closed manually close it by timeout
    // setTimeout(()=>{
    //     disposable.unsubscribe();
    // },10000);
  }

}

import { Injectable } from '@angular/core';

@Injectable()
export class Constants {

  constructor() {

  }


  public static CHARTS = [
    { key: 'people_by_country', title: 'Xente por país', abbrev: 'País'},
    { key: 'people_by_state', title: 'Xente por comunidade', abbrev: 'Comunidade'},
    { key: 'people_by_province', title: 'Xente por provincia', abbrev: 'Provincia'},
    { key: 'lang', title: 'Idioma', abbrev: 'Idioma'},
    { key: 'group_type', title: 'Tipo de grupo', abbrev: 'Grupo'},
    { key: 'age', title: 'Grupos de Idades', abbrev: 'Idade'},
    { key: 'travel_reason', title: 'Motivo Viaxe', abbrev: 'Motivo Viaxe'},
    { key: 'overnight_accommodation', title: 'Aloxamento', abbrev: 'Aloxamento'},
    { key: 'consult_reason', title: 'Motivo consulta', abbrev: 'Motivo consulta'},
    { key: 'transport', title: 'Medio de transporte', abbrev: 'Transporte'},
    { key: 'duration', title: 'Duración', abbrev: 'Duración'},
];

  //public static API_URL = 'http://185.129.248.113:8013/server/api';
  public static API_URL = 'https://arousanorte.cocodin.com/server/api';
  //public static API_URL = 'http://localhost:8013/server/api';

  public static QUESTIONS=[
      {
        question: {
          'es' : 'Idioma',
          'gl' : 'Idioma',
          'en' : 'Language'
        },
        field: "lang",
        index:"1",
        answers: [
          {
            text: {
            'es' : 'Galego',
            'gl' : 'Galego',
            'en' : 'Galego'
          },
            value: "gl"
          },
            {
            text: {
            'es' : 'Español',
            'gl' : 'Español',
            'en' : 'Español'
          },
            value: "es"
          },
          {
             text: {
            'es' : 'English',
            'gl' : 'English',
            'en' : 'English'
          },
            value: "en"
          }
        ],
        template: 'simple'
      },
      //---------------------1. Discapacidad-----------------------
      {
        question: {
            'es' : 'Discapacidad',
            'gl' : 'Discapacidade',
            'en' : 'Disability'
         },
        field: "disability",
        index:"2",
        answers: [
          {
           text: {
            'es' : 'Sí',
            'gl' : 'Sí',
            'en' : 'Yes'
          },
            value: "1"
          },
            {
            text: {
              'es' : 'No',
              'gl' : 'Non',
              'en' : 'No'
          },
            value: "2"
          }
        ],
        template: 'yes_no'
      },
      //---------------------2. ORIGEN-----------------------
      {
       question: {
            'es' : 'Origen',
            'gl' : 'Orixe',
            'en' : 'Origin'
         },
        field: "origin",
        index:"3",
        // answers: Constants.COUNTRIES,
        template: 'OrigenPage'
      },
      //---------------------2.1 Codigo Postal -----------------------
      {
        question: {
            'es' : 'Código Postal',
            'gl' : 'Código Postal',
            'en' : 'Postal Code'
         },
        field: "postal_code",
        fieldLabel: "Código Postal",
        index:"4",
        template: 'numeric-simple'
      },
      //---------------------3. 1º VEZ AROUSA NORTE-----------------------
      {
        question: {
            'es' : '¿Primera vez en Arousa Norte?',
            'gl' : '¿Primeira vez en Arousa Norte?',
            'en' : 'Have you been in Arousa Norte Before?'
         },
        field: "first_time",
        index:"5",
        answers: [
          {
            text: {
            'es' : 'Sí',
            'gl' : 'Sí',
            'en' : 'Yes'
          },
            value: "1"
          },
            {
             text: {
              'es' : 'No',
              'gl' : 'Non',
              'en' : 'No'
          },
            value: "2"
          }
        ],
        template: 'yes_no'
      },
      //---------------4. TAMAÑO GRUPO---------------------------------
      {
       question: {
           'es' : 'Tipo Grupo',
           'gl' : 'Tipo Grupo',
           'en' : 'Group type'
        },
       field: "group_type",
       index:"6",
       answers: [
         {
           text: {
             'es' : 'Individual',
             'gl' : 'Individual',
             'en' : 'Single'
           },
           value: "1"
         },
           {
            text: {
             'es' : 'Pareja',
             'gl' : 'Parella',
             'en' : 'Couple'
           },
           value: "2"
         },
          {
           text: {
             'es' : 'Familia',
             'gl' : 'Familia',
             'en' : 'Family'
           },
           value: "3"
         },
          {
            text: {
             'es' : 'Grupo',
             'gl' : 'Grupo',
             'en' : 'Group'
           },
           value: "4"
         }
       ],
       template: 'simple'
     },

      {
        question: {
            'es' : 'Tamño del grupo',
            'gl' : 'Tamaño do grupo',
            'en' : 'Group Size'
         },
        field: "group_number",
        fieldLabel: "Nº persoas",
        index:"7",
        template: 'numeric-simple'
      },
      //--------------------------5. EDAD--------------------------------------
      {
        question: {
            'es' : 'Rango de Edades',
            'gl' : 'Rango de Idades',
            'en' : 'Age range'
         },
        field: "age",
        index:"8",
        answers: [
        {
          text: "Entre 0 e 9 anos",
          value: "1"
        },
        {
          text: "Entre 10 e 19 anos",
          value: "2"
          },
          {
          text: "Entre 20 e 29 anos",
          value: "3"
          },
          {
          text: "Entre 30 e 39 anos",
          value: "4"
          },
          {
          text: "Entre 40 e 49 anos",
          value: "5"
          },
          {
          text: "Entre 50 e 59 anos",
          value: "6"
          },
          {
          text: "Entre 60 e 69 anos",
          value: "7"
          },
          {
          text: "A partir de 70 anos",
          value: "8"
          }
        ],
        template: 'numeric-multiple'
      },
      // //------------------------6. DURACIÓN VIAXE-----------------------------------
      {
        question: {
            'es' : 'Duración del Viaje',
            'gl' : 'Duración da Viaxe',
            'en' : 'Travel time'
         },
        field: "duration",
        fieldLabel: "Nº de Días",
        index:"9",
        template: 'numeric-simple'
      },
      //
      // //------------------------7. -MOTIVACIÓN VIAXE----------------------
       {
         question: {
            'es' : 'Motivación del Viaje',
            'gl' : 'Motivación da Viaxe',
            'en' : 'Travel Motivation'
         },
        field: "travel_reason",
        index:"10",
        answers: [
          {
            text: {
              'es' : 'Calidad de Vida/Tranquilidad',
              'gl' : 'Calidade de Vida/Tranquilidade',
              'en' : 'Life-Quality/Tranquillity'
            },
            value: "1"
          },
            {
            text: {
              'es' : 'Casa Propia',
              'gl' : 'Casa Propia',
              'en' : 'Own House'
            },
            value: "2"
          },
           {
            text: {
              'es' : 'Clima',
              'gl' : 'Clima',
              'en' : 'Weather'
            },
            value: "3"
          },
           {
            text: {
              'es' : 'Cultura (Patrimonio Histórico/Eventos)',
              'gl' : 'Cultura (Patrimonio Histórico/Eventos)',
              'en' : 'Culture (	Historic Heritage/Events)'
            },
            value: "4"
          },
           {
            text: {
              'es' : 'Familia',
              'gl' : 'Familia',
              'en' : 'Family'
            },
            value: "5"
          },
           {
            text: {
              'es' : 'Gastronomía',
              'gl' : 'Gastronomía',
              'en' : 'Gastronomy'
            },
            value: "6"
          },
           {
            text: {
              'es' : 'Medio Natural',
              'gl' : 'Medio Natural',
              'en' : 'Medio Natural'
            },
            value: "7"
          },
           {
            text: {
              'es' : 'Proximidad',
              'gl' : 'Proximidade',
              'en' : 'Proximity '
            },
            value: "8"
          },
           {
           text: {
              'es' : 'Playas',
              'gl' : 'Praias',
              'en' : 'Beach '
            },
            value: "9"
          },
           {
            text: {
              'es' : 'Otros',
              'gl' : 'Outros',
              'en' : 'Others'
            },
            value: "10"
          }
        ],
        template: 'checkboxes'
      },
      //-------------------8. PERNOCTA----------------------------------
      {
        question: {
            'es' : 'Pernocta',
            'gl' : 'Pernocta',
            'en' : 'Overnights'
         },
        field: "overnights",
        index:"11",
        answers: [
          {
           text: {
            'es' : 'Sí',
            'gl' : 'Sí',
            'en' : 'Yes'
          },
            value: "1"
          },
            {
            text: {
              'es' : 'No',
              'gl' : 'Non',
              'en' : 'No'
          },
            value: "2"
          }
        ],
        template: 'yes_no'
      },
      //-------------------8.1 PERNOCTA ALOJAMIENTO----------------------------------
      {
        question: {
            'es' : 'Alojamiento',
            'gl' : 'Aloxamento',
            'en' : 'Accommodation'
        },
        field: "overnight_accommodation",
        index:"12",
          answers: [
          {
            text: {
            'es' : 'Albergue (en caso de disponer)',
            'gl' : 'Albergue (no caso de dispoñer)',
            'en' : 'Youth Hostel'
            },
            value: "1"
          },
            {
            text: {
            'es' : 'Camping',
            'gl' : 'Camping',
            'en' : 'Camping'
            },
            value: "2"
          },
           {
            text: {
            'es' : 'Barco',
            'gl' : 'Barco',
            'en' : 'Boat'
            },
            value: "3"
          },
           {
            text: {
            'es' : 'Caravana',
            'gl' : 'Caravana',
            'en' : 'Caravan'
            },
            value: "4"
          },
           {
            text: {
            'es' : 'Casa Familiares/Amigos/Propia',
            'gl' : 'Casa Familiares/Amigos/Propia',
            'en' : 'Family/Friends/Own House'
            },
            value: "5"
          },
           {
            text: {
            'es' : 'Hotel',
            'gl' : 'Hotel',
            'en' : 'Hotel'
            },
            value: "6"
          },
           {
            text: {
            'es' : 'Pensión',
            'gl' : 'Pensión',
            'en' : 'Hostel'
            },
            value: "7"
          },
           {
             text: {
              'es' : 'Turismo Rural',
              'gl' : 'Turismo Rural',
              'en' : 'Rural Tourism'
            },
            value: "8"
          },
           {
            text: {
              'es' : 'Vivienda de Alquiler/Intercambio',
              'gl' : 'Vivenda de Aluguer/Intercambio',
              'en' : 'House of Rent'
            },
            value: "9"
          },
           {
            text: {
              'es' : 'Otros',
              'gl' : 'Outros',
              'en' : 'Others'
            },
            value: "10"
          }
        ],
        template: 'checkboxes'
      },

      //---------------------------9. MOTIVO CONSULTA----------------------
      {
        question: {
            'es' : 'Motivo de Consulta',
            'gl' : 'Motivo de Consulta',
            'en' : 'Reason for consultation'
         },
        field: "consult_reason",
        index:"11",
        answers: [
          {
            text: {
              'es' : 'Actividades Deportivas',
              'gl' : 'Actividades Deportivas',
              'en' : 'Sport Activities'
          },
            value: "1"
          },
            {
           text: {
              'es' : 'Actividades Culturales',
              'gl' : 'Actividades Culturales',
              'en' : 'Cultural Activities'
          },
            value: "2"
          },
           {
             text: {
              'es' : 'Alojamientos',
              'gl' : 'Aloxamentos',
              'en' : 'Accommodation'
          },
            value: "3"
          },
           {
             text: {
              'es' : 'Camino de Santiago',
              'gl' : 'Camiño de Santiago',
              'en' : 'Santiago s Way '
          },
            value: "4"
          },
           {
            text: {
              'es' : 'Información en General',
              'gl' : 'Información en Xeral',
              'en' : 'General Information '
          },
            value: "5"
          },
           {
             text: {
              'es' : 'Transporte',
              'gl' : 'Transporte',
              'en' : 'Transport'
          },
            value: "6"
          },
           {
            text: {
              'es' : 'Otros',
              'gl' : 'Outros',
              'en' : 'Others'
            },
            value: "7"
          }
        ],
        template: 'checkboxes'
      },
      //-----------------------------10. MEDIO DE TRNSPORTE UTILIZADO--------------------------
      {
        question: {
            'es' : 'Medio de Transporte Utilizado',
            'gl' : 'Medio de Transporte Empregado',
            'en' : 'Transport'
         },
        field: "transport",
        index:"12",
        answers: [
          {
            text: {
              'es' : 'Taxi',
              'gl' : 'Taxi',
              'en' : 'Taxi'
          },
            value: "1"
          },
            {
             text: {
              'es' : 'Vehículo de Alquiler',
              'gl' : 'Vehículo de Aluguer',
              'en' : 'Rent Car'
          },
            value: "2"
          },
           {
            text: {
              'es' : 'Vehículo de Propio',
              'gl' : 'Vehículo de Propio',
              'en' : 'Own Car'
          },
            value: "3"
          },
           {
            text: {
              'es' : 'Barco',
              'gl' : 'Barco',
              'en' : 'Boat'
          },
            value: "4"
          },
           {
             text: {
              'es' : 'Autobús',
              'gl' : 'Autobús',
              'en' : 'Bus'
          },
            value: "5"
          }
        ],
        template: 'checkboxes'
      },

      //---------------------------------------


  ];

  public static SATISFACTION_CHEK = [
    {
      id:1,
      question: {
        'es' : 'Tiempo de respuesta',
        'gl' : 'Tempo de resposta',
        'en' : 'Response time'
      },
      field: 'satisfaction1'
    },
    {
      id:2,
      question: {
        'es' : 'Nivel de satisfacción particular noutra cuestión máis',
        'gl' : 'Nivel de satisfacción particular noutra cuestión máis',
        'en' : 'Satisfaction level'
      },
      field: 'satisfaction2'
    },
    {
      id:3,
      question: {
        'es' : 'Trato personal amabilidad',
        'gl' : 'Trato persoal/amabilidade',
        'en' : 'Personal treatment/kindness'
      },
      field: 'satisfaction3'
    },
    {
      id:4,
      question: {
        'es' : 'Información recibida',
        'gl' : 'Información recibida',
        'en' : 'Information received'
      },
      field: 'satisfaction4'
    },
    {
      id:5,
      question: {
        'es' : 'Documentación',
        'gl' : 'Documentación',
        'en' : 'Documentation'
      },
      field: 'satisfaction5'
    },
    {
      id:6,
      question: {
        'es' : 'Idioma',
        'gl' : 'Idioma',
        'en' : 'Language'
      },
      field: 'satisfaction6'
    },
    {
      id:7,
      question: {
        'es' : 'Localización del punto de información',
        'gl' : 'Localización do punto de información',
        'en' : 'Location of the information point'
      },
      field: 'satisfaction7'
    },
    {
      id:8,
      question: {
        'es' : 'Accesibilidad de la oficina',
        'gl' : 'Accesibilidade da oficina',
        'en' : 'Accessibility of the office'
      },
      field: 'satisfaction8'
    },
    {
      id:9,
      question: {
        'es' : 'Grado de satisfacción global',
        'gl' : 'Grao de satisfacción global',
        'en' : 'Overall Satisfaction Level'
      },
      field: 'satisfaction9'
    }
  ];

  public static BASE64LOGO = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAEqCAYAAADJZC6LAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QTVBMDRCQjY3RThBMTFFNzhBRTY4NDUyMjc5ODhFQTciIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QTVBMDRCQjc3RThBMTFFNzhBRTY4NDUyMjc5ODhFQTciPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpBNUEwNEJCNDdFOEExMUU3OEFFNjg0NTIyNzk4OEVBNyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpBNUEwNEJCNTdFOEExMUU3OEFFNjg0NTIyNzk4OEVBNyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PucWqzkAAJXuSURBVHja7H0HYBzVtfa3varLcu/dxqYZGwOhQ0IgCRAIISEhIYW0l/5eyvvTQ3onvbeXQgiBEEKvhgChuAHuVbasXlfbd+c/Z+6VLTuWdqWd1bbzmYNW0mr2zp1bvnuqzTAMCAQCgUAgEAisg00IlkAgEAgEAoEQLIFAIBAIBAIhWAKBQCAQCARCsAQCgUAgEAgEQrAEAoFAIBAIhGAJBAKBQCAQCMESCAQCgUAgEAjBEggEAoFAIBCCJRAIBAKBQCAESyAQCAQCgUAgBEsgEAgEAoFACJZAIBAIBAKBECyBQCAQCAQCIVjjwR7bSL+5kORSknkktSQpknyxODtJmuQykoglV+SWBkgOkexaCnj6rW7zl0nOIolP1DPW/dRJ8iLJfSRP5Otx/NoWwltt/VgKRz4+oI7k1STnkUwl8ejxJSgc+EEn9YzhcfV3kharP6TRFse69KlA9E6ao14a1eF83MspJJeQnMgfqedOWh5x4fYnvXaFSHaSPEDyj6JpnW8arjtwB3639TO0Ek3Vzc0z7DYYiTRu7ojgUDKN6S67OQGzGKSvIrmZ5ABJTIbWYf7AO36H3htvJ9l0vDe+95ePjusDnBY2lje9b+hFaiLRYhm5Yrj08Guvpq0jYXVbmRx8vIAD6rUknya5g+T/kbxQQpPhYyT/S1Il60LR4jqS75DcRPKFEmr3FJJvkVwrj7Co8QGSHST/RXJvRfZAyoDNbcf7p/hxd08Mjw0mUOuwmZIcXY3B5PR5kitkGI2Iz5HcRnKjVkhYwuCsAC+qDxWAXEGfOK2DU3P83tlEtiw9JZ+miU0x4DUkm0neXQKDfj7J0yRfEXJVEmCt4udJtpPMKoH2vkNv2kKuSgMLSe4huaUYGpOw2Sf2A22KZIEI1SWTfHhfo8/UYLUm03COrkBjJcSVQrAy4kq9dr2nWAjWN/XJohB4BCOo9Ma9NfTxaF0CePsBw1KV75+LcDD9kOQtRT7g7ydZLfO+JDfCJ0l8RdzGVSQ/JQnK4yo5XE3y3cI2wVY4+zGTrFQa06vd+OhkP4I2G5oTaeZdmcBmsLfL8BkV7IryA5KTC02wTiX5cAE74sMWzxegnSRNZwKHpWbqj5DMLdLB9CsofzlL4LS2bT8u4n4TZMY0kgetHxaWoAlK6y4oXbwfyixdACh73HnhA0R0IpgQ/6vjNSGeAtwOfGRKAPNcDrRkR7J+QfJmGT4Z8U+SmkISrP8r4M1vIFlv2UAd0l51LqIBy9ory5y0V0D5phUzPmrNZdLYbUta1SZ2NL5R5njJYy3JuUXYLta8i8m59PG7gjxHuwtI9uM1fRvpMF5gBSiRKrjsuGGKHzOJZO2Jp7MJMeJ++38yfEYF+2Z+kcRfCILFZpvFBbz5u6ybLPoAwnFQTKysdW6/vQQGEp9mAlZ0ZNA6s+rHZX6XDS7L9QKKtrNWOWWFtoBDWa6Ux1I2uHDCP9FVB/RswrR+Ilju+sLevU2TLLsN75jkw1wiWx0pIxuSxcEod8jwGRVvJbmqEATr6gLfuHX2d9ZecaBm93KrtVf8cOaVwCAKWLNIpdFrsywjx7kyt8sGl+Z6AdORy5illRU5H4Dm5nIqFRQdlk3opxlE8p1ufDa0C4i30S7qLnwPDJEsIlfvmhJAvcOGtlRW5sLLoYI8BCPvjeP2xcqFYBUyQugfmhJZMzDTQ1fjU4BlBMGHgjthjnnTyRnN1qSl4r5zy9wuG0xBjhpS5UzMqeMs0WBNl0dSVpgxoZ/moOUpEcGbep4holVDhKtIknXztEimzQjDtzd4kaZm9WWnyRJXjNFREBNhIU+AX7LsSmwsGCQZWECvQ1ZGDt6K0vLxMAo6Ev9zXEqJgfJCToTZDDmxcQQKOxTn7DPvLPG+5E5oIzkIlQewv8LHVvXErZJE8L2T8KEDd2Be212AZ1rx9QaRLI/Pifc0+hAhlhU2Mm70D0OlVhFYvHblstAUagPcCxX+bdFphKSLB6WHJo5l+Uo5re8rS2wQFVPGakMIVlkhnev4ch4+DVnCvYs9+z/n4dmvv+7Vr3mVaoUKxeEEfSEcUefxuYarZrA7whKonHvnoDTcE4rmcJjdQAwC0Q58q4XOz6764u2RRBqTq9x4PZGtX/VETef3DKqDz5Bcg8L6VZfd+CpFgvVHS3npAJ8FaR1yD1rZxu/JmBQIBBnAYTXPQuXz26q/5wzSzWO8Tp+WfVob8SP98xOgUuncQHK2bIC5fgqdETz1+NBe2oJ6nwGqlhePeXAEkrWkxoOz42k8PhjHbCJZGU4W7DP8L5mWFvLxEmzzRsuuxIdh9r2KB4BAh1XO7byoXSVDSyAQHAcvQdVrvEdvZok8ftYLWn5Dcj7JV6GSqwrGA4cHSCXxoc7HaOesLoSKwQtlc8lOG8Dkj/67tMGLtmQa++MpTHHaRyNZbBniqhlr5GFXJsFiV4wHLCNX7DPbXwO4I1ZGDv5WhpVAINBg0yiHwtOujKe0FAKcVJVNh5yegvMfnSyPZgxg7ZW3CTfsvw0zOx8E/Gx9nRCGxa4mr4AqQ7dYEyxWCzwHFf33M6jibscHFyjkHFn1XtzUFkYobSBgHzUD/eugNKECi2hGKYHJVZclV3Lrc0B4ipVZ20+XhUsgEEA5n3P9zPma1HyngORqOG7Tm/WX5RGNAa4gHe+78Yv9v6P9wg/YHHn/RKhE3pzvkYtbn0nSCFXGZRFU7cxPk2wjed+IVxmKLPQ68Lpaj1mzMDG60zv7+31DHnhlEqy/WnIVmz588DnAoC6wWebfLTWeBILKBpv+uIQXpz35BJSTujWLlk2LNfgkVKHrTnlkmWCYiUU/ffBOgBOLeqcrjVb+cBaUKfkNWbyXAxxu1jIyiFgtrHbj8hoP+tLpTBEnQr4tQqmZCO+w7K45DqdvNk0cyyIHOaTkbTKkBIKKJVZcVuOJ3PZyVi/Qoc/poq+0UDkcSlKpIw7Vdq09SSdp40wAiQTGaa76uV5T/00yRx7hSGoIN/X/ID7U8TA9l6p8O7azFWTdOP6OtVica+6GkTgiJ8Y6q86D7dEkDiYNNDpGNBV2Q2nOLpWHXzkE6yn94HMHr08cPZgg8u+xLIWMlHYRCCoPz5N8neRPORMr1k4FdEqngV4gQqfAyCBJCAjROpUmkpVOK/LV0AT4abP3055a3UBEi8hWlBY125iNEqzHfxnJo6ictA5jeTC0RzTC2/4EagdeoNeTkUffq5XILYqPowDvJvnLcX/LmUeddpzud+H3vTGkR0/z/kkhWJVFsB605jQCVdisk02DlqXD4WqfH5bhJBBUDA5orUGOWnVDLUpMlBy0HLfRZbdvovWpjdapOB0CYyTxo82DTLJYq+Xy0oZPUj8JWLoKmDYLGCQiFouO1ZTI97JEb+4SZTgc7GtF/f18y230HAYVwcqPeZD34seRe5mCX+oxGT/ub1MGltW4cUosiRdjKTQ57CNpsWgQmhVTLpNBUBkE65BlBIt92mNT6e7jVrXtOgAOGU4CQUXgR/pAFc2NWxG58hKxcrmBLlreXnyOqM4uWptogfJpwuXxq/ccj5ixRiIaAXa8ALQSR1pyMrBwOVBTr4gWmw+z12ixnfHlUDm4pE7jUB+7G4Ge57G0+wl6JtPy6XvFZMaKyh982P8ayQdHHHN2O9YGXHguksy0a31BCFbudKNUsMWSqzj0spj00d1bpsF6hQwlgaDswW4K7ID8npzIFW9yrIGqpc071As8eifw4O3ArpeUVqq2gTZ2j3rPiJoom/LV4vc1TFbXfOZh4N6/AC8RUfPSPuuvHqu/ELtgsJmqXx71UB+7cEf7A0R6O+l5ePP1Qd/R5NYqfIBk6Yi/TRqY7nPiFJLu1Kjjg33zdss4KH+CxUa9Z6yaM6b/FZfGsaY6DPfheTKUBIKyBue3W4tcnNiHyE5VLeAjAvTis8B9txKxelH9nIkVk6qxOlGzyZC1YPVNSnP1xL1E2v6u/LeYxJnXzHqt2yVai6GVnfo03oXzBraqsjj50V41aEJkNd436jh02rHA7URfKp3J9PKgDITyJ1jPalqU+92yInyQI3QsS6D8ekxksVGBQDCR4Gx5ryW5PqermGVWvLRS1AEH99C2dRvw5P2KHNU1Kcf1XKPT+O/Z8b1uErBnG3DPn4BNTw3TZmVNEDiK7bsV/+SdASKpB1EVbSGCVZWvT7krT9cdvRYuDYVFXgfqiWhl2Am/I0tA+ROs5y25ClN19r+KTKHJY1ly0bfIMBIIyhLs6LsCKjnn+EkPo7qe1hw3HRUfBR74q/K1Yl8pr89azcjQ57Hmih3kmcQ9dietexH6PFaW2LIlcuzD83TlPnrW8vhxYz8R1fB+2jt8+fiQ/0H+ytLMgapDeXyk0ggQwVricaArOer443xc62UpGCdHL5F2braMTprpGehk4h6w4oo1JOfKMBIIyg4c6v66nK7A2ikmUOyk3kyEauOTQGszUFVzRGOVmeywLw2XSKlX7Ag9UGa80WuymqVdAspJfiftkV3ttJVfAEynfTc8oPJqZY40ZM3dgcp8/Dazj97Qu1GdzK3PfcUZ2b+a55t4J8mNI++HNqzwOvFsJGlujaPQrO+T/EKWhPFRjlI5SeY8X8yIaOZVhmXZkF8NVdJAIBCUDz6bE7k6rLWqU2H+Tz0APPhXFSlY16iiAzNv2K+Cqh/IGoS/6Q2OE4NyNYsN+ndXZNUO9s3iXFr3/lmlgGBzYXZpHA6S3FSRI8BFfTS4G2f3PmfWIMwDPjMBd3EdRkv7kDIw3+fAVKcdkdGH46+gUnMLypBgGfrEZs2VmKZbl//qYhlCAkFZgesHfm78a4x2OA/UAD0dytmcNVe+KiBYmw2xWkByJwn94ajBM/w7Nl3+lGRKxjaxb5bPDzxNZK+jRTnaZ2ea5MLQFRZJZpgZ26/pJ24b3kuEOGD1B8xEfhzbjwWn27hoxN/qxKNsJmRn9ww757OyNJQnwaIRjracr8L+V1wVZ9DS/FdS2FkgKB9cDVU/cJz7snYyZ7Pcc48Cd/1emQQbp2QbHchkZgfGFsX3Dk2ATszYNjYZcl6sJ+5R0Yb+rMu+VNZBkvsoncD7uv+dr0+4bQLv5trRGYAN012OTAWgGT+Q5aE8CdY+y+6U/dqTASs1WFNkCAkEZYH3k9w6bmLFJjfWUMVpkVl3l9Jaub2q9E12JIZLk3xhnG1nD2zOAr4iYztZs9bdDvzrPrUourLycGALQuU4vNs9ZnqGUwfpbO/kvJ2W+l8tx8Rmy1876m/TBma47Qg4zPRYo+EWSGHwsiRYe6w5lZAwr0pncOcb20RpkCEkEJQ82Ffl5nGTK3ZYZ3+rPVuAf/we2LtVRfG5PNmSK968cvV1YibAvqoZNFlp1ba924GXnqG/qsu2jW+tmNFgo+eZ6IMvOQA4LE9q//UJvps5GC0zf8pA0OvAqV4XulIZ98UPyVJRfgTLmhI5TLDMovOO3Ks9KZwqw0cgKEkkh71+N8n/jesqZpSgX2munlunMrLHo0BVndJoZUdcmFhdbeG9ZdbCmdq2GmDz00DLXu0blnFz5Uoav6uI0eEKYm6Ytp1Yi9XZ29ml5JIJvhvOqL1kdBZgw0KPA2EarxmSjtLpAS2yfJQXwbLmgQ6RKusiCE+R4SMQlCSGskZyzbYfj49cpY44rT9yO7DxCWUOzN6vifFlKNOglWAn+dF9fEx/LJ8qIs3ldRJR5ZifGZwdvLe8h4Yqvv2Jvk2mFsvCErO88fyxQDc1ehkeHU24xO1AXzrj2P2JLB/lRbDaLLkKmwfZt91uWVK/pTJ8BIKJgdrmfPpAnvMcngel6fnY+PZg+vzqBpW8k0vdbN2oTG1MUrInV+w4/vE8dRenb7hhdIKYVslPD+0H9u9S7U9n7FeuUXhnWQ800zw4gEs5gtA0D1rmf8VpNxYX6K7Oy0SwQOSKc2L10esMpOD7shqVF8GKWHJ2YCQsbdd8GT4CwcSA41MC6NKnJHeul2OSMD6zHBMoJiPhfpWRva0ZmDR1LCZBxiySP+S5y76UcX3n9voCwDYiiP3dqpRPZtxc1gPNzH+1B9MGt9Mws9TFtpD+S+zo7h11f6ShMNfrgNuW8fjCBcE/LCtS+RCs3HMq8ABir4sEV0dPWtGmGr1ICgSCCUCv4cbZji2A8w7aDNjCl5MWa++4yRWXm2k/CNzxW2pUB9AwORvNz7HgiL98B8hQw/DNjO9ik2bLHmDPVh3xmPFeniG5uzxHGQcs+PCpnvW6PI5l/lfno7AVPzgA4sxR35Ey0OhxYI7bgd5UxoPCt0m2yapUHgQrd73TEMGKTbKKYE2DZHAXCCYQTqUgcv6Z5jPPYc8E772G8rnq7SR6RPwiHlHO7GMnV5zIdOYEtZrrCS4Y/b7SiljtIvLa26VSS2TGJ8pyiHHW/VQcl7F50OaysjzOD4vg7s7NOL6ddqzwOhCiMZ2F59lHZU0qD4KVtOxOHTGdpsGS06FAIJjAZWCf4cDLHQ/TRvBPmsdcviQ1MR/Nmw/7K7UdUMlDo4PKB2vs5OoEjNfva/zInJWezYTtdG+7t6jXmYkFF+h7rOyGGGdsH9yH1QMvEH+fZNVV34XC+V4Nx0UZ35EycGrQZSYeDWV2dv8HlDZTUOIEK2HJXUZJ4nQCtVviiFUnQ0cgmOiFQKfzcX0bsBG5Mfz5/1AmUVxWZrAPeII1V/FsTWnHw98K0G2vRKZQOCZUbo9KQJqg86w9q23hrvIjWNQHsU7i8vSs7W6rrvr+Irm7BZnHunJ2PyvgQk9mZ3fGNbIqlT7Byh2Hk4y6rMqBVS1DRyCYWLgQw/60H692PELf/JiIQSMsSho8AvFIq3xRfd3APbeogsmsyUqP6zM/ltUmZz2IHZoleEYH+2Id3A0c2qdeZ8aP9bG1TGCYGdwvi9OzTvTTa6cVF70KxRNtzj5/czOTLGClz4kqhy0bzQYnAReH9xInWEYRtikoQ0cgmHgk4ECYXzh/QoelcP60WEyi/ESuUkngodsVyQrUjldzxfhkAbvtvzO+g2slxmJA8071OvOyyykbflteo8vAW/s20zOPwqKTeLHljDo74ztSadjddix2O9CZzMoXix3eD8rKVLoEK/dMb7wmsk+sK6QyuecOtwwdgWDiwVqsgzSfX+7YRCTrfprPfDC32BfLTF/gV8lEH/uHSmHA5WXGT644wWQhtd4BkndmvGfW1jXvAlppv/RldYa8qUiGRe4HXs55FW3Dlb3PWZWe4Rsk9UU2fa7N6l02Gy6pcYN1ePHs1BtnkQzK6lSaBCv3aD1eF3m0OCJWObkbMnQEgsIgMZSI3fldncPHSi2Wri3IdQSfuAfYvVWZBcdPrnjzeX0RdNs7M6+0dG4c6AUO7Mo2s/t+FEfKhq7cHjkRaQ8944G9QGg7Pf+cuTAf5z9ShFPn5Zpsj45kGl6vE6f7XWjNTotFHSf+WKVKsHJvo06kBsNpVZuEYAkEBTtxsS+WA5c4H6Zvfm2xLxbX6atWyTd3vwTUN+Uarv+tIum25ciU24JJpEc7u8eiZo26LHBrge/rWWTjYzYanETQ4904uO8XesfJ2crxqSKePm/MboczcHGtG41OGwazm1oc9FAZtSrLjGB5i7BNYRk6AkHhwBGF7IQbcH7dOl8sM2KwDmjeDfz7QRUtaM9pieR6pacV0Tp6ccZ3uf3K3yzUR+TVl8117y3gPT2m+7d1/EdlLtjdiHcfegjT2u4EfDOsyH+1qoinzvuyepcun3MGa7FSqWz9dN5Mcp+sTqVFsKxJ6Mlzhk69FtUiFHuzQFDQRSGGNprKqx1cM+7x3H2xeFMNVCli8eT9RNrsKulmbpvtT4us267K+A42j/b3AC17lTYrs7KeHZzvL8C9PE9yTs5XcbiBZAL/1fUEPe9JuZiCh6O7iKfOCmRbhYRI1uk1bsxzOdCVXdoGBpsh98kKVToEq8YScsXWQW87TSZL/NO7ZOgIBIVFBFUq2sT1NSJEqfFrsYwhvyu62nOPqmzt7PCd22bLDsWnFlmXcRFoR8bF0kV9cXAPEA1nay774gTfx/9Z0rfse+WdjNceugdLW++g1zMqZeqcny3B4uzu19R5EKM5ksz+rJGbVlEI1oSiyTKC5bTslrtl6AgEhYXyxXLjUteDNLf/qn2xxqHF4kLNrL164d/ArpdUxGA6Z03Gl4uwy6qQjcnSQ0S1t0c5vHuyMhOyqe7QBN3D30mus+RK7HuVCOHXB26h10GltawMvC27eUGSSKM+4MIanxMHkmk4s8te0UGyxjwDCcEqelh3rHBYdiWOnklDIBAUFAl4EOFyeq5P0WrWTiRrjBFghs7Uvm8H8MwjVvhdMbiw7uwi7bILMq+TtFBGQ0DLPuqLrD00vjIBbees6K+x5lLsY9SITzffhmD340p7ZVTMks6Rradk/e6UgUvrvZjhtKM9u6jCoT3yZJJmIVjFjWlWzCVzVLCbp2FJArk2LQKBoIBgLdYhw48LHNtpjj9J85sTl2epxWItlTdAb6f3b3xSabI4PUPuTs5fL+IuOzG7t1FfdLRQH8WRZdLNfJfOYa3LzZZdzeY085y9s/tftAv6K3HqZJ9Ggk2FLjve1uA1p0Yk++mxjeQkqIzvQrCKFHMtuUpa363NsCrJwjbZ3gSC4oC56Dt/RfObYwt92f0R199j8rCOuEFPu4ogzF2LcQnJ2iLuqhXZMVeXqrvI2d0dWeksdkPlQ7IaG6DMmr+07Ipm5OAUXNh2P6YzweLIwcrLvPOGrPdWbSr0B1x4RZUbLYnUWIxB3fr53YoKRCkQrDmwqoKgY4hpWYItsq0JBMWAJA4YDlzuuoNI1p00xSeZPxt9kzWUaXDLc8BW2sP91Vbtsb8o8s5ahGyK1bu8Kl0DRxS6PVnRFpIfWdxWzoC/GirXlXVwEAFPhXH7/t+rbP12Z6VOnMvGNs3SWF3rwUK3A4ey98dicFDY1SRfFYJVfGiCVVosuyZY1tC152RjEwiKA5wXy0yI6LqJ5jmRgtEq05hFnGtVpNyLNI1rG7SDc84M6yKSqSWw5md2u+Doweigiqh0urM1m3LtvZgFbeQw/+uhtCwJa2+f7sPTiA8e/DsCPU8TsZ5VSb5Xx+KNY3o3mwrtNrxzkg9V9HUg+9QNQ/g4yVsrSTlRKmETi3O+grn4kjiTVpXLeVy2NYGgOMC+WHuMWlzpfF5FFLKSxmFTROEoobkfqAEiA8Bj/6RNI64j5SxRX32+RLorixp5huqr1mYgGc/W8b8Puef++h6Uli0/haS179VHOx6h17wh2Cp52nCk35nZ9x1MLRa8Tlxd4zHL6IwjZvfXUFUFbhGCVTxYlvMVeCSwk7ungyaYx4o2bYfkwxIIiohkxTFgHqRuI+FcwAHluD5cONcVO7U/+YBKQxCotSIlA+PVJKeXSFdlF+Hoof7raAW6O1TS1ezw43G26SGSy0k+QBLPy11r36v5neswveepSvW9OhZjD8hIpDG7yoVzAy60JNLjCc7nTufahWw23FDOnVsqxufcy00YUBosHy28IXrhjFhxRVZlN0AgEBQBkuih1f7k+N1Y/+TPaJ7TBuoJHXOktCvHbfYvqqm3yjzEe8zvS0xzkbm9nHyVTYTtB4ApM1TiUVtGjc9LJC+QnJBlW+7Sm/yjeb9r7Xu1Yc8vVJJRTkFhVHy2HQ7IeBnJuux3Pt76bLis0YdDrYNoTRqY5LCNR5t1q5Yh/6y55da5paLBOskSgsV3a1oDLLtt8cMSCIoINTS/13ecDeyks2PvdpVqYLiwyYtJg8ebDVnIFqy9qiqhbspyPeVcUS7VZ9FIttGEjLdn+D2z3jtIXgHlaJ1/cqV9r9578B8Idj9VaXmvMuHNYz/LGKYJ/to6L0Jpw4zizWFX/QvJQpJ3k2wSgjXxWGwJu+XAIk6T4+0F0paUOPyVzE2BoHjg4hWtlzZPex0Q8Ks8V8PFF6Sv/mEncUvw7RLrJrYIBLN6p69K1SVsP6iSsGbXZ0+TvOWYnx3Q6+UroUyUbA6cuELRdg+t/yF8/dCdNEj4+dtkshwB5xgbW3CGTt0Q9DlxXS37Y6Vyjc9nBRibl0/U+/1noTShJY1Sik/lzLN7cn6EPLcCtFj0LKHTWc4BKk+S0HEYjTJHBYLCIqEP1ogElcbCmJBN9GMo3qztI4GdUFfo9SsDMdFn8O0bgelzldkwlciGoPxGk6opJC9qzURhVEZsDvRMAjrWwddPzfBMhvhe/QddYjPt2EsQpQysIIL1sngaT4YTmEknnFTu7WH/5s9pYSf8V+iv7OPos+B+uawTm7Lp5GAmDGd/IQ475oFBxMDU8A4vWhwc7weVEsHKfREbMhMyyeqyrG7OzXogCASCAqLeFcfuPlonD81Xvpb5B0e7faVEu+vsrAgWa6w46nLPNjpGPg2sPF3lxsqOuz5YFHfq8Ju+V237fqM4nhk9KObBY8ApG35I8q+x7anqIHNZgxc74kl0EuFqHJ8/1kh4QguDUzbN0l/Z95kT3s2Eskuxid6hySKfAEJaDkLVRuSEpxzlykWod2D09B98KFhAcgaU+TRUCQRroTWnGZjBRbBbll7lh0KwBILCo5rOtv9uocNnNx1Eg30T8ZEfLeHu4np02SV+ZF81f0AVw565QCVoDQ9Y6cOWP5iRg424vvk2NLU/QG1fKuRqZHwaSls0NnDqBpcdNzb48NX2MEKcZs5uKckaQruWfKNVC6di+hpy0GCVUvnwSyy5CvthsQaL/bCSlqRrYBPhQzI3BYLCIUFnRTOzdMsi+sZFm3/eN1E+8F1f4gQru9wLrKXw0KIZjQJbnlepLuwlsnU4ud2d+MWBvwDueojv1ai4EMpENjbo/Fh+vxNvrfNiIG1YnR220Bi3BquUCBabCFfkfBWm1WzFrSIiHOc8OZbw7P+TuSkQFA61zjAO8TJ4aJ4yD+bf/+rvONpPo+S6DMrckh2GSgvt2Ajs265ep4tAE8QaKiZ8HLzAJPAooYW+ugHn9jwHR8+z4nuVGWxi+8v4lRdpzKn14Ey/C7vjKTikP1FqRZheQ7I590kJZcHtiqhowtxPu7+DUreLs7ug2MDJcNleFoXyO0gNO8YbmiSwUwqrwdnRs6oUb5LTMzy4jQ7gXVPpTvrz/XHvGddJv/jAfibbs99+Hapu33OP0fo5WUVjxiMomFaISZ+/BgjT8+44pBzwjwJ9HwrhL4f+Rr8L6HYKwcoAzl/2DpKfjWtfJZJ1cb0XLfR1L5GsKU57PkyFQrDyBHbE+2LOV4nr81vVTqB3KZ1scl6QE3pQ/k3mp2CCwUbvXVCRWs1Q0TEcGbObpF8TrGxU3A5NsNiOwsWA5+gDAzutTIeqpsCpUrzF2AkO1sW3LaSZ6FEHpvxqsL5VJmPnUpJ/jonQsMN7J5GZ7ZuA1eepQ+pE8ytuh4O2rqoaRazW3U0jvPc42eaJYKVjaKzbrTL2p4RcZYmfjItgMbiPXXa8pcmPb7aE0JEadxJSIVgFwBItW3OboPoww1tJn2WT7na9uS2T+SnIE1gLdVCPf868vBEq/L3FgmvzGtijhfHscd7TNGwOci6lk6Hy50zWBG0kMHHLmzuC3ZZEimlmNECLezzf5Ipz9XjKZDxxgtT3jm3tJPJaRfx7Gw29mfNpDaVHH+rRxbLzzqx0kFK1qiu5jYb+Mw/REYPOt/7q/zRZ2ujnRh3eET8JP/PzdPHJCpIdeAJx4NZnxvWX2un9jfVefKsjDA+NjWp7ZZIsZwm2+fycCRaDdU5sJmxrp4W53orSOYyPkNwt81NgIf6ttQyPagLfXsC2DEXxPIYjRX3ZLjNJE60lw14PJ1UcIp2XvAmJtA+LGvtwf8sCoHkh7aGhfN4/l/S4sYzGFhfjO4/k4TH9FWuKWGP0+D3AxVcpX6d4FPlVZWmtlb+K1uwDdKx4SiVAdVFbgnWK+B0v0zwR7p/HZ+JnCVrjHWEiYV5ZUbIDRxQ+MuaxcWRiYkrAhQ/Cj590Rsy4zRoiWZUWv1mKBIvraP3QkvM6z7UArf3902ki0sJs5OyWRyuO6SO2QuanIAc8pknVHZYcJvILPqq0aJnQ0lFpw0uLeB9aB6gR666n/7lpTofzqcH6dhmOtevHvIkymQnWqOzuHFW45gIgFs0Pv2JzIGur/EGVFmL3FuBf9xKhixGFr1fRjKOVvLHFgWQNvhCZj09VP0mDxgfxw8oa7PA+fr/iZBrTqtx4Bz3Dn3VFEUkbaHTaTdJRKUTLXoJtfj2UB1XuYJI1jYlWPy3Ofqva93KSmMxNwRjATugcicpBHOzzdA5U0MRW6ZqRyJULdZ5+0HqN5+/5PHBgPlDVk09y9QMoX7Ryw7Xj2kSZ+HCxbDbTHdyjyI6RB+LC5sAgyc4XgXtvAZ68T2mqaicpwpXxM22m5urTkSUYiHMJpRAkVUPWYBvP13K6QjyFGQE3PjctgPODbhxIpNGbMiomwrAUCRZHPb3BsrM3x05N3Uds2zL7PKfhf5fMTUEWeIbkA1AO5Vym4u9CqrIjV37XIKbRvvvIk28H9i0E6tutLOJ+LLhu3nvKtDt5PT1vXH/p8tAaGgWefkhFE9Y0ZEl6MhA3jgZkDRmTNtaSPXS7IlZtzdRan0rBMJZCzeyLlfLjhsEl6rVosMaC/4bKmZaDIoN9shw4p8GLD0/yoc5hw3YiXv0VQLScJdpuzqD8Q0uuxBGF7Lrb1qtIljW+WL+Gqgy+Wuan4Bhs1ESKvW7vz41oxA+fEyKquL2pOmUP7Cqbm36egqsMlzCvfRC0VuO2f10DbDgbqO2ijTNvtQfZkeDPZT4mqSPHkf9oyOG9n/r/n38CTlxLR4VFynwXDWefjNQ0A9pVMW438b1Qn6p92NkGNO9SWeMPmwONcRA41mIN4tb4DBjJJtgctNan/bISZQ/2K+byMeP3o2THd3oMk4MuvMvtwObBBDZEktgUTaLBaTf9s8w1TQhWUYDDxbkq+z9zvhJHH7HyqolOSntPtIpgMc6FCpevkvkpINwLFfr81/H88QCRqQPGMSuQ/YgKYrG9ChGEabA5zPduScWHjo9HDuy2I19nkHht7KFeOrkyWXNltyWwmA5Et7xAh+rHXkvkqpPmbDyf2qvbUdoJRbMBdaTpLDH2aFQzF1W1iiR86G/AkpOB084D6ibRoGUikzwSYcjvZQ0XEyX2q3K61Vf+PhlT2qpD+6gV+4GuQ/zAlXmQzYFM5nLRjLHmKlmDL0dm45PVdJtpzoslmqwswXaeP0JFnY4f3N2JtHkSXFHvxYpECv/uj2M9Ea198bRZiYGjDQMFIltDyQXMZhrqJ5x1IpfoR2cJP/Q3W0KwGLwXcdxTz05aKGbRztNjhcM7MzWu6/SEzM+KRbM+/f0BKgpwDBPTg1ZjAB16di+gmfoq9yo0uiZzURjUOOsxxT2DFgKzSAxqXZMQJ2LlJNYVNaLoSrQRgfKiN9mJnmQXERMbwqkQBo2w+bO9ye3YyStYWhGxOtrj6mh18diKl0swuZrkj+OWbauJXF1LRxfOfRTLJ7m6CcqnshLAPmZXjG9n0iTLQ2Rq63qgvxtYeipRttnE4GlvTqWGMfy01nDR8th/SEUfRkJAR4uKDhwcpGv5lWZsuKYsZ7AWK4L/jSzCJ3x7YXP0CckaG15F8iWST1pwUgJiKZNorSaitZpI16ZQAgfpawvJ7kTKDE2upt+7aN3Kh1M8P/UotSNKL5I0flnP4rINrb0287P5H9dU9OSgGC9lgnWZbn/SEi0WGwLm0eR+ke31PlrN41a0kSuT/xfJzTI/Kwqc9PPLJH/CGA5ATJR6iAAd0MRnBo3uNwTPxyLfCZjmnosaVyPcdh+tSw69r6X0wmPQwTAGmy6+a6d/c33Ljpz46ecGbVJJI0nvT9HaFkZfqgf9RLw64wdpYWvGltgG7E/1ooc1Xza1H/EWp0iX35Jplgs4HcOySX149NAc4I4PELGKqoLO6byRqwst2UxKB+xndoZes8ZHslgbxZqrzlY6Tvxd5cliJ/WkrkzHmqw0TYdQv4o65AzsSRpXnMSMUzCwibDenx9nefPzOaKwFleHTsCttRw4KWbCMeITUJn/f20F3zWJFguRmJW1Hqw09+I0doWT2BRJ4iC97ksZGKT3+O22YQQI5oGRNV72EShyXI8h/hPWQiX117gmU376+6kulZ+LzZNN+rXbDpPUTXLaVS1z29BVKo9g8fGDHYS/acnDZucVztwzZSew/0R6Ap1WtfP7UOr3T8j8LGsw1+Hq69/DmMyAagq2psPoYVJFe9QrvCsx370IK4NrMdU7j4annU5bIcTTUcSS0exO3amB/9QAaZuinQhak3s6ZnjmwRk8AzEjit5EOxGuHnQkDmFXdAva6WtfugObU12IJ8PmHJlKf17Lm+gE+3UxuZpZ3Yc9PUDfw+9QyUQD/fkkV6zP/kMFjmFOLnlRbqoBQ5Eq/tqyT5Grw0lItYmQyRQLO8lzHiub7ei/zxv4s0P4a3wm+hNTUe3s1FoswRjA+e84FZF1KVmGiJZanDC/xo35QZfpHN+dSGNHNGVqt/rTyik+QmMkTm8fIMYUpzFlH0aA0uD32FDrsJnv5dMtEyiPXWmm2MGeidUMYlJ1LodyXLXh6DE41Kbh6q4KJFiML2kCY01aBL4Kp94LvQT0LgJ8XVaYCqFPwkGtzRKUF7gcDZtXOMP3/rFNvSS2pMMmNZtHw+x1NVfg5KqXocE1mU5sQSJVYSI+HTjiHZArA0zrtSONZCqBiFlBxzCJV8BRjVpXExb6V+LU6nMRSYUQSw+iJ9GFA7GdaEu0YH30KWxJcZ6plNJwkTTwiQ/5I11MrubU9mFnz2Ts/dtnVLb2mq58kit+MByIMKkCxzJr7bh8zl05kywGF2AuNtiSNO0C+EZ0Nj5ffZDGURBiJhwT2HrHVR7Wkjxl/TFVky1e7hx21BMJWuN3HU3C0iqjfxcRMDbzOYaRo7Shvp/M+VuGHKrsmkDZFIE7TKbSOmAijbyNgVInWOww8j8kX7DkakOmwvl06tpMm0+sWtUptIZkvV8PTknhUB5gFSdHsn4XKlN5lhPOScMsdtgJ/URnA15eezmWB05DvXsqEkaMyE0/yeDRJ+88nur51Bdj7RhJSBMuu81JpKuWSNcULA6eQkQnjvPir0ZnotX04dod3YaX4hvwImvKmHAZqSE1GSbp5tbYMCyKcexzKEGb37RgNzz0p3ufeDvQVw80teSTXDH+r0LJ1RBu0fcfLs/bU75YX4jOxed928zoQvHFGhfYt3QejpTWshaGJupDpGq4lsmpvja4HSMvjWnj+KTfrEc5cc/aWQYP+qOWESx+WGyBYdP83H3AtuX0QDy0aVjmf/JuPSDFXFi64OzqXAz10bFuQkyuNpsaIOAK/+lYW30hprlno841mQjVAHoSbZZpq3IlXGkjgSRJLB05fAysITLY5J5F6xudKtMXoytxCN2JdsSJFPYlu+h1G/Yk9qA1uQ9KOxc/QryMccTiuLrRReecnrs/CzTPpW2/Nd/kin3mXlfh45tXP04fcmbZ3qHpi1WNtwyuxK9rHhNyNT5wsu8tUEEgG/P+aQaOPCfjqB8WNcqBYLHnFNcI+4s1k0+TLD7D9b8IHFxBS063le1lc2EvVKZuQWmA2cHv9TPbMlZSFUEMOzmSKhXHqwKrcE7NKzHXtwQeRxCDyR50ElGxDc+hUIynflrMokS2oppwsZar2lmPRvd0OGx200+MHekHUj0YTPWbr7sS7eZ7+1JMvrrgsmcfoeiwGWgMDuAzd60BXloMTMs7+WR3g2tkqJtgZ3f2b/1umTIsM7v7b2Jz8IPENgScXeKLNT5wkfdHoGqQtkl3lCfBYvyI5E5Njaxhy2zB4Wxb0c10hF5upT8Wg8sPcAj/L6GMkoLiBOeu4vqSt2FM/lVDpsDkYY3VW6ouwTzvUiwOnETEpIEIRytCRERspotmVqSBVTcvg0pey6VNeEfgnKLsOchhWjRATbPlBqgoxoF8blDKrBjRGq5h921zodY5yXzPFM+cw5GNYyVGLk4b4XfiM/YOmiEHYFrX81cG57MQrfKx+I4+WHy/PDkW+2L58a34LHzK3SK+WOMHa7LY6f1dep0UlCHB4ppJX4QyF1qDpO4dJlkDMav9sRicuO1pTQyXyVAsGsT1s/k5VFTgGCeUBxHiNluSysfq5d4TcE71pVhRtRYOm9N0Wm+LNcOutT5Z4HSSN0HloZmZZTO4tiE7orL94z7kwxl1pGmjTYuMaHr8iZ/ZRxUJjsPmIsJ5jVr8CsnHZNgfF5xeZp9eo8qNYZlj69PhBfiUdwe9Fl+sHMAnKo6cZvP6X6Q7jj4Vlws4Qs9h5fw77I+1cKfqqpTP6jbvJjmV5FcyFAsKPqlz0tr/JZlP8paxkiunPqtsTg1gJ13tNf7T8PGGd+GdUz+FE6vORB8Rq474AZN82G0Zp90ckrdBldN5EqoO3swxNKeG5AKosHv++5egIh25sO8SedyH8TEhVxnxd0sPrkW1+7EvVhDvH1ym/LKEXOUKDpD4mnTD8H2hfMAOHpyD6L2WkqyI5uexrcDOEwFfN/3c0ryyTONugEre9jeSehmWE4bNmtzeCmWyHccEUlGBm9mhm4bFatdkvKbuTVhBpMpB//qSnQilerQpMCOx4vxL7Pvy3xYffpZqGSpY/LA+cXKup55ifDCm19eRmhX5WPd+R/J6mQJZ4et6/LytvG5L1Si82czuvh9TnYe0qVCQA3jtOofkDSS7Kr0z7GV2P7yBrLT8qkyy2J2vcSMQz9sEZHPOQog2K99gbQ7XBDxDj5Vvj59cebA3HcaWVAor7H58uP7N+O8Z38ZKIlcDyW7TeZ2zp2dBrGbqhWmP1qjke16eB+Vbs5fkN1AlnYoqNQFHWfv4yOS1w8wqaG2PrBVyNWbcoA8ka8uLYyVpsLnxrehMXb3DJk86d7CfKAcDXSkEq/xwv+VXZAMSK63YuFKzFYjW0jzMy8m6Wy9kJ0IVmRVYgxeg8qWxr9tykndCmc7GrQCJGXFsTg6YHuafbHg3PjXjpzi37nKTUHHqgpSRysZ5ndk6VyJgPxdWrXsmuF84Apdret6tSSb72lxVDLtMksuV0f++erqTUzFz+mYrLy81UsaHE6BK6bCmfU6ZMCzaBcP4RnQWIomp9G1UnrI14JyPrCV/Wu9nQrDKBE0kb7R6DkKX08ICWujdYVrw6+jnqXzdwyaowqtvIdkqc3VcOASVCJTz+ayAMnNsyeWCrLFiYrUlGcZuItzXVV2En8/4CdbWvAIG/etNdCKRjmQbFcgpAViF/uEiOTYzueP6nuykyr6BX9QbaqG2PbT1A+cvdMB9qpuOHikrV6uETI+ccLlel7je5vQCt2UxyWtzmkN2lRfrl3G6FXtEnq61YG0WRzazP2iVEKzyAKc/mG35ih/VvHz5HiBI+3ekId/3weabpXrju1fmakY8A2VqO1U///divMVrjyJW2oE9OYDdtM+/u+a1+P7Ur+HKSe9ElbPeTLkQS4eHDZSMxIoXnD/pw0AxgrUT7PC/WZN9NltfUIiGtA8Y+NnZNOlmkAyKE3IRgQn5xzUZv8fyQ21mcMqSv2ui9yHk5KFuMw/LjoIn+S1rfFqPle+gdLSfq6AsSeOud1yuBIu9N6wPLR4qCs3RvCd0A9V7gdAkIO3MpzaLwbXB2E/mQr2YCY6A81NxqP0afVr6BsnzVmgpjkQGhrElEcflvtPwjSmfxmWN12OWdwHCyT70J7u0xirjwjwFKlkpE6tSUpmz9u8tJA9AadzYZ+2iifhgTqHVPkCdNc2GJSvpWfSkynfFKu219uV6bG8nuQlKq5QP1OuxyGlH2Gf1VfrnljhTuySKMN/g/H0cxMNh+Zy0eWGRtvM0qGodfGB/DXJIo+Qs44e5Qmszvm45yQrr89vSQeDgBqCF1pM0nbBdISvzZB0PD2phZn2ufvhnVeBEZcLJpWo419PD+fgAu81jplxg/7srg2fg1MAZWBI4DT6HH53xQ6ZJ0Gb+y7jju/VJn0PdS11FzrXHPqhlr+5//vpvKJ+2A1Z/oMOutFjXL3XiE0/S3IrRJugSLUORgjfMT2rZoA86ezQh4tdjLYkxXx+aTtHXZi1qsIIUBeUK3iT/R8vf9Nj4M8mOArXHp8cW76knk5x/zO9bhGAdH1/TD3Cn5SQrBmUuXMCPZxt9wlIiWbVEvHrzTbKgN7ZntbaGCRaXCnqd1pIUFGHrerhx2PcdJA8NI5i789N6pbPazOa+ZBwr3FW4vP7NWFV9Htx2n8q+nuyBzZZ19nU+Cf1RbxTlhjk4WtXPYSBP61Mfaxc4sGCbFR/Uon2xZq12Yf+DNPEmOSAoepykZQgRvQ5zQMcuPae52sBQ9V2XJk9s2ueo2kUoG0d6wSi4QssX9PrB+zVry5/L42fyoZcjyM/Q+ycTqoYM+5EQrBHAG/JSWF0dnrucs72HoFI4eLfQtj+JlowpVtcuzITHtbC2jlX1bL7h/PNrMwyavKB62MDKoUQ2L7g/hqrZeLeeeLF8tpup1QEiVj1EE1a5p+Os6nNMYtVAr5lYJROdiljZsjos84j4FKzMyVb8sOsxx/J+/bMdmmSxBoM1yfHxTrWBWBofWOnER55LqBBDp2ixSgysJVihRSA4HtZogSbh67W0QuXr442VtUkcwBQdYYtx6rHGB3TOK1in90EWDshg/1yOJJ+QtDSVQLBmQTnp5qeQq6HPZpw7ewUdynaQdNAa4iXm5YhMhDZrCLx53YkjvmfsKcYRdJzziB1CWfXpz+9YsOMaw4/v2XLmQkyG3z0xE2CIWMVNivCBuutwZs0rUOWsw0CyB22x/aqsjS1rKwSngGDNYsVFzBwHC7VwkMYPx02wiEuFiVe5mVS5bcpMKBAIyhnztVx1nN/16z2CD+ApfbhL6z2Mz/jBYll/nRXysNh89qhe5PMDftyseGRdWdVmYP8S4teeiTIZHg9cCO4+LdAMntWirLZnn4bZmsXXao2LJY08w3DhTJsDT+iuKFZwyoVWYwAdqbhpcXpb9auJWF2MSe7piKQG0R5vNv2r7NkTK/ZPYq3VW2RtPO6CmFP5AwfxqihrrvgqorwSCCoZ1VqmFHtDnRX0ULgWWydUvSTrYdPnc+bT7EEQ3ArsmqJSOXh7i+H+u6Acwh8+zhhgVaoFJjh1iHiXEcATtn5YWRrSSnQacXRwMWZq3vtqr8EpVecQsZqKRDqOnkSHdmAfk98sE6vPy7onEAgEgkokWIzfkjxC0p43ksUcg7VZrBc6oRXY0QZ0n1AIk2G2YDt2c7k/eI4K3JEaQJyez1TiTm+tuRSrqs7FXN9SROjnR4iVLVsHdsZ8TdxfLkuJQCAQCCqZYHFyBU6eyI50e/P6SUMmw2UG0Tn6yN2LgISXiFZPMZIsyxlb8QxwbQpMxDHbBby29s1Y4j8ZUz1zkTaS6Iwf1OkFx0SsGF+CCixwyjIiEAgEgkonWAzOns3+WLPz+ilDJkPmUmyA825XJsNoHb3uI5IljiT5HNaH0y2wjxV9c2PtFVhTfQGme+YhdFhjlR47rVKRKJzdd5X0s0AgEAiEYB0NjizkXBuXIp/h/8eaDE9sBbZ0Az2LJzqVQwURKwcRK5Ug9GXe+Vhbey5m+5Zgnm8ZEas+tMb3H/avso3dW5qzmHOUoBQLFggEAoEQrBHAmVu5Tt2pE/JpTLK8JEviRLJ2A73zAF8v7fJpGYUW0Kok8eQtqbhJaE91T8K5NZdgVc0FqHc2EbHqR3v8gC5oM66kzxx5+TOI1kogEAgEQrCyAqcr4Ezb10HF/+UPQ8Wi2Qts+SCwczPQtkJIVo7EKkLMdUtSpVe6wr8aC3wrsDK4Fo2uqehPdqI1vs8kVbbxxfYzG/swrC63JBAIBAIhWBWA10MVc8x/Ad6hEjvs/L6Ee59I1kFOStoPOGJl7/xu3ZCNYVc6hXhKJQd9U/AinBBYhQX+lfA7qs0CzEN5rGzjL1PGGaf/iuItSCoQCAQCIVhFD07A+XcoTVZ/3kkWK1xYacVB/m4iWXtoL3dHJqJYdAkPVKWt2plS2qrVzslYFjgFS/0kwVVw0L/eZIfpZ5UjseIHwKVevglJaSkQCAQCIVg541UkW6FSOOQ3L9RQHUPOD8BJSX2cxmEuEKstZOb3IqZWwOZU2OyvK/xrsbrqHMz0zEeNa5KZu6o/0YnU4YhAey4fxs/+NySLpd8FAoFAIATLOnBCBS4sfCHJS3knWazF4jqGXKjGvYfo3dxiyvxecBxODpoCTvdMx2vq3oTlgdVw2JzoT/WgJ9GuWaptvD5Ww8G+Vt+UXhcIBAKBEKz8kawXSf6L5PsT8okDUKUpVxLJ2mlTmd8r2vmdh2USLyYGUGcHPtTwdpxafS4Cjir0JjuRNJLDCFXOxOpiqOLMK2ToCwQCgUAIVv5xM1RByS/l/ZOYI7Ami9M4LDWAHZuB9hXFXF5nBKii5qlUj/ndlnEHZio/q0t9J+PKhhsw3bcAfYkOdCYO5RIReDx8kuQmGeoCgUAgEII1seDN90yS66EKReeXZHEaBxfJIpI6dn5fACRLxS+LyJVBN5DqwOTaq/Bqz1QsTUXGdaWkEUPAWYcTg2tht7nQFtuXq+P6sbhUE+eVMsQFAoFAUGwEy14hffRKKOf3N5Lcm3eSlYDyzWJDpWcnsHO68svy9FOPp4q0xA4NIyMMxDvQWfdqHJz8drzTSMEwEuMcWDak6N9AsofIVsJKYsX4OcnbZOoLBGUDu3SBIM8784QTrEpyECKGg3tIPgPlrxPO66Pknh0kqSFZeRDYc1AlJS3KVA52Ra5SHTjUcDVubbgSrkQ7etMRM64v9+6wbO18M8lHIb5WhYAj102Qp4TdDqsSZ0iYbnmh2PYisQwJcmb+gxXYX5+D0madOCGfFtFPiJMGLNqs1pFIfZGRq6ipuTpU+zrcPOXtcBkJ1KTClpArizCF5Fao9AtCrgqHaE47Fg2nCLvmpSwhWXF5HGWFniJrT1IeSVlh3OtFLgRra4V2Nmeu2kDy/6BysucPQ0lJeWuaTrJ0NxBoA2LVxLXokGRLFbAbmFwNmpqrzrrX4NaGKzAr3oaqdARJW9Fo7G8k2UHyWlkjCort+riQEwzOyGFY0p498kjKCvuLrD0vyCMpK/QVgmD9ocI7/Qt647gm7ySLNxVO5RAkObGLyNYWIl5BRbQKQrK05irRjf11b8T3pr6r2DRXQ35zP9a9Jigs/pHrBVJpepBcx9NpCcniDblHHkvZYFORtedv8kjKBrTh4l+FIFg7SR6s8M6fTfInkt+SzMk70eI6hqx8nkuy6EXAFVEO8IZ9AokWk6s4kasO9NReilsar8A0el0kmitO2fodkrsg2diLCf/MefjT+E+mYZUGi/ELeSxlAY7ufqTI2kQnYHTIoykLfB2qjN6EEyzG66T/TbyJZDfJ70im5ZVkMY9iF/smkpXNwJQXlTYrEZwAkjVErtrQXH8tvj/lXQimwkSuCq65Yi3VV/Qz+IAMx6LCr0meKsJ2/TfJNnk8JY9LUJw+ddfKoyl5PEvyVeQQRJErweom+aA8h8P0h4tFs2bvs3n/NCZZHAu1kGQxHZjsMWBwUh61WUNmwTb01VyCP026Go3JXk2uCqq5uhLKVPsxEr8Mw6JboN5axO27AFbqxAQTjQ/rMVaMYOvOx+URlTQut2DXzBnfJXk9lJeQAPBBpXNg52outTM9b3SO00yx63AjyYpmYMZm+lkgT75ZadOhnTVXP57yDgTSg6hODRaKXPHdv4fkeZK/QmUNExQXOHLzjCJv40GSVSTr5XGVFFij8CGSbxd5O78qCoiSBGvcT9PrQ8EJFuPPUCHwf0Rl5ccaDQtI3ktygOQhkotIPJZ/Cp+/WZvFGeDnkyzaqpKSWm0yTB5Eb9Ur8eumN5jEqiZJ5KowPlfv1GPsByQnyzArOrAGl80jV+sjQLGDSfopJF+UQ2JJgAMmlkD5WpYCWAFxAsnt8uiKHhz4whU+1sIizaiVCdH2kbwBqr4bk4lGTSgqnXDVQeVi4pMyR7Y1W/4JQ9oslkkkwVZgSwMQq6EnHLPszLjdf4L5MKvTBSNX0IT1S/purQvcF+R6UOuFCk9/oETv4VMk3yI5F8rw7pe1qygw5HnaDuXMvr0E7+FFkitIlkOVXmvSe6+Mr+JYuzinJ/vv3k/Sb+XF85Fxdi/Jz+S5FQiszeLsXN4uIMJsK2bZMAykBuE1EoX2ufonLIhKEwhGOMFKiL0gn0TrRemGymJvgnI875lnIzkgCQQCgUAgBEsgEAgEAoFACJZAIBAIBAKBQAiWQCAQCAQCgRAsgUAgEAgEAiFYAoFAIBAIBEKwBIJsYJMuEAgEAoFACJbAAqRpiDjjQDXQ2OiCLeBDOi25PQUCgUAgGA1O6QLBiMTKGwFqO4GBGtz72ElYlw5h5hVtaJhdh1DHIOKDcdgcotcSCAQCgUAIliA7YlVDxKpzCv719Gr8ffMU3LajAXWRDizZdRcWXbgU89fORe30avS1DsAwDNhsQrQEAoFAIBCCJTgabPVzx7TGqhb3rTsTf9wwBc8eDKLGk8SqphBsDg96e6J4+CdPYttju3Da1SdhzqqZiPRFEQ3FhGQJBAKBQCAEqwJhT5EY6qsjQRLX5IqIkScMhBqxfv2p+NUzM3HPjlpMr4pjRVMYBv2J6XaVNOCt8sBf5UXXvh7c9ZUHcfq1p2D5yxejqjGAUJd6r/AsgUAgEAjBEpQpmSJxEYmqbqOvSSJH9H28hsQLhP1IxD0IxbgqtAGnJ4H9PVX44VOz8MS+GgTdSayaGiKyZMOx/uw2g//CQFVTEMloEk//eT22P7oTp193KhasnYu+9hDikQTsdmFZAmvAY459/ZxeF41rOhQYPJhlfAkEAiFYgokEF3quJaki6XOiecdy7OwO4OCAl0iUD60RJ6JxJ/qjdgwkHGoDox1sIOw0SdmSxrCpgUobGTYwYl4ujwM1RLSYVN39rUex9po+nHjZcri8ToS76ToOCVIVjB8crer2ueCv9cLrSCGxp5cOCjQunT76bVRIlkAgEIIlmKgdiWQWMPACcNPPXoOesAu7et1oJ/LkIhLldqQRcBmw2w14HCR2pZ5is15TVQJO+p5fG1lmYRh6H5OsaDiOx3/zLJo3teK8d52B2hk16DvYT6RNNkHBWMexQRzKZZqdBzoHseWB7TiwqQUDB7txbiKAR+qWA456OkyE9YlCxphAICg+2AxjnDmN9siiVlTgfWY20LcdeNPH34itHT7Mbgqhxm3ARcTKyHPqKnZw57HUfaAPddOqcf77XoaZJ05Dd3Mv0qm0OMALMixEMMePr8YHb60X/W0DaN5wEFse3I6Wbe2wOxzw13gwzR1HFC78IrgMCMwnMkYDPx0WkiXIcf0M4OfVz+Ft/o30ukb6Q3A0vny3EKzKPfGTzAT6dwLXf+yNaOnzYuGMXiSTE2+iszvt6DnYD5fPhXNvXIt5p89GuCuMZCIlJEswwvg14Al64Kv3oW17B/Y/fwD7NxxAy0vt8AbdCNT5YXr+cbAFEamqdBxeI4713ml40r8QcLE2a1D6UTCWrY/+G7Y+poL4RfW/cYNvPb2ule4RCMEqWww9Ep8W27CfHQ+0HnRtAt76ievQEfJg/vTCkKvhJGuwN4JQZxjnv/sMnHT5CvQd7BOSJTgyxA010AM1XnhI+g8NYPu63Xjh3q3oaelHgMhWoMZ3mFgdfZ6wwUH/n5wcwKDdjZ/XrgE8M2hjHBAHeMHxyRSNE9gcRxbYNI0TI35krCQD+Ev9s7gqsBGI1pbnEOJ7cqRVJHnGCUpv5j1EinYIwSorYsVCB3IESA4CLc2atIzAl9JeoI8O7zfdfA12tAcLprn6T5ZlQ2wwjmh/FGffsAYnXLIUA+0hIVkC03ndV+UxTYEd2zqw97kD2PvsfrTu7EKw0Q9fwJ1VOSYaSahJR2nK2PC7wHwk/IvMnyIdF5IloCHAUaceWlMTQKKHCEM/pqUjqDJSaKSvjckIklqL1Ze2Y5Y9hh/N6EN1gMZQzFE+Q4jvw5UyCVN31IkdUQdCKRvcxyFaSSJWbpuBuZ4UpvmJhDqJkMUdMpaEYJU4seLubFDEamALcM+6hbjv38uw91ANHHTqsNuO/5wMmiSpsJvWkSQaa2nBSBRP5B6namDn94GOQbzsbWtwKmuyWgeEZFUwsfISefI3+E2yvfWhndh87xbzdYB+5qv2qqoAY1iSmGT5aQNtSg7gL8Fl2Fe1Um2oqcjRJiBBhZAqpyJVvKgmQ0QOOnBmoh3z490IpGOHjQEpmwNx1mjpseaypfFM3IMmpwP3LuoFiGAgWuIkiwmUK226kOzq8+BHnV48T/fUnbYhYRw/wo29TXjWBOhv1/hS+FBTBLOq46of4o7K1WgJwSrVXYekRhGrgy8B656bjz/9cw12HKzBlPowaoMxRaSMkR4gzKhApzP/juzjm+Q2xIlkDXZHcM47TseKS5ehvy2EVDwpJKtSzg80MO0OO6qbgqbZeP/6Zmy+byvad3ahalIAbr8byLGAuI1W/sZUCBu907Gu+hS1TaQllUPFwDQBOhWpSvZgaaILJ8Q6MTk1gASNhQG7l0jV6ITbRUNlC5GIha4UfjE7BH8gqdbnTGPIZGxFZE4bprHaFnLhtl4PbulzgcvGznKm4LZl9jrhmKk9dFjn911bk8DlNXHMq0ooE2OiAomWEKwSJFaseZ1MQmvCb/5wAn52+2qEwy5MbQqhNhBDKl0mfUwkKxFJYKBrEC+7fg1Ovny5SbJEk1UBxIqW6ECjH063E9vX7cJzt21Cx54e0/eKTYRj1VhlwvRELzb6puPB2jOoASkhWeU7uhSJHvKtSkUwObIHF0QPoCYVNgl3iEhVzDa2TERMsl6IOTDDaeAHMwdRT4QiPMo6zJogHzWj3pvU2qIC+i4NESvCth4PvtPpxeNmih5gPv3crYlTtuDtKUb3sSPhMLerC4hw/ldjBPNrdQWQSiJaQrBKCDzKWWtVB2x/Arjpp6/Fhp2TMGtKP6p8caTTZdi3piaLSFZHCOfdeCZOfPVy9LWI43vZnh/SBvzVXniCbnTu7saL923FCw9uh9vrQrDeTwu2tcRq+LllcjKE9b5peKJ6ldqI0zEhWWUFepYOHz3atBk9OjnajIsizahOhxG2exBh36sc4KTL96TsRKwAj330vIBx+h1rhE7wpnB2MEGSRN0Q2WKilbJNSHeYxIr2jb0hN37T7cHtfS7lS+VKZ9RWZXN5/vvtmlC9ngjWG+timE73a5ohK4FolQTBsmmxD/tqxxEfJO+w70d6ylG9ito0UTH092kU5iHbM6z2xyNXjerlT361Er/66xq43EnMbBowS9MY5TxQtbkw3BvFWW9ehZWXLcdgTwRGyoBhG/PANa9ntw8fMDba2NOmuYlJG2/ynIMr5/WLrmV32A7n+uIM9YoUqoHLPzN0ri9+neb7ydODtJn3rO/brj7P7XHA5nT8x2fy+1LxNJKx5OH3cp/Y8txGB/VPoDFAzzmCjf94CVse2Gb64tVMrjIjTHM1B2aDqck+rPdOx6O1a0tMk2UbRWMzhmvYbEeuZZrGnP95De6Xw4vUUIZhozj64HD7bcO0VS71laP/Et1YE9mLxfEu07cqYnfnTKyORdI4/hJ+7PLP72knQtZFZGq60zDJ1lU1cZzFvkvelHqDaUK0je1R2vWbzb0yfaQv+DopvfFojdWmbi9+2uXB0xEHkT4bFrnHrrHKVqO1jQiVl5pwViCJd9ZHsbQuptmmI7/TwaaJgukXkx55rgwntWPt85IhWIZ+It5hEtdPPKZHJX9N6PfR962t9KM4L9DHOxHTz2lMTZ/Kgwqqtp5XrxtuLS59Pc47GBlGxHLF8Hvx6M9xDruHkUYjo1u31a7vfbL6u5u+dB5++c/lWD6/C1XeRPmYAzOtGTq6kMvrXPi+s7Ds4sWmf9Z4SE8qkTpMHtQg4fI9TlqHHSbhcdJr1qDEaHOPEqkbS1Z507xF7/fVeIm82JEYTCCdTJvX4M9MDSNUTCj4s4b+xhNwm7XzIj3Ro9s35smp1gcuF8P5oPh1IkqfnVCkKR1PmW0b6AyZxNV+zMRJp1LwVnkRrA8gmUyZ7XS5aeBS27ickYv6KUVtjtO9JeiZmNNlHE1V922nvvLQdV1mG1teasXTf3jOjAysmRw086JNBLEaDnZ8f943Q2uy0kWmybIdIQw2+7DNc4Qt0XTITo58D/x7Jhh8Lb6GKUk9EGKaYNqHLWgkjoDyWzr89/oa3FepGCYsSz632Wy7XlTNtqeVmG2wq3tJ9KA6NYhTk72YT8TKbSTQb/chYXMUyxM1CUhb0o52Ws/XELm6ujaOtcEkmthp3oZh5ID3heNofhyG8nMaliYhTYThAJEa1kjF6HWjy0CACBS/r3XQZTqv39bvMknPHJf1xOp4Wxtv5TvjynR4LZHJtzTEMCUYV0OMidZ4997hqSRM5Yk2t3J/aA/8RMKGFvoMrkZy1HpnmEsbJrtTRz7brvucr2nT5Gs8/nJFQbD0QcM0f/k1yWkHDhwCtrbWYs/e+ege8Ju18KI0uCKDboRiLjictFnRgGzuqCKC5TCj5v6TYNmJYKUxo2nAfL9Bg48dwDl6rsqdQFUwgiXTWzBv5gHMn0E3Nl2PhF7djvE87KH7adSvW+heiDC1t/LX2fDYU9jePB3xJN2D48iQTqUciNKEeOXaR3HyxXq009+A2jSwB3jv567CtpYazJ3Sb25oRqU5DLJPFm3oTA6a5jUixcRljJ3AmhAuKs3EwqYJjMEJKwMek2Sx6dHpdqB2SjXmr52DacsmI9QdRmwgNirhsZmnVlrA6nym8/Xef+/Hjn/tNUkhkzZ21o7S61QiaX4uf6bT5TRJlakdoktz0sxpS5voc+fCHXAh1DF4mJBlTVjoc4L1PjM/B5tSuw/0mk7hbGJlYhmnNsSjCZoLdvO+EuEE7VFHq1MNImKeKg8CtX7qj6TpB8VkjfuO2xucFET99GrUzahDw5x6useYqV3MtlC3qT3zu82+SsST6NzRiX3rD6Jjbzdat9PETxlmxOBEE6vhmJLsxybvNDxcs0ZN4oJqsgwd5eZVkY7UNqTpazpippZw0cg7iQhE+piju5fIRa/djRe9c4ltN6gIyaEcThwxx0SNywbR9VyJbpySDNFZMIlgKm5+ZpCuzZIaNv7s9Oz6HD4zko6NSFE7rcn0eo8jiBZO3OqepEiPWY4onYc+021ncsQEMNln5jFbSV8D1Cc0m+ChA4KP+olTKfjSSTTQ77mPotSuEPVHihZnexHapoaMM520ke9NHtFq1RBp8LIijtp8biCJtY2RI9F5QxF/UQce6PPg+YgD7bTHhehHnFKhOWE3TZFM4Bpof5zrMVBNf/P4oBNt9PulRCpceSZWIxGtl6j9ddSWC4hIvqo6jlX1UdUBMUf2HebUpIh4QT/93Ra6/43UF13UB1G65zj1Q1faZvZBJxMs+rnnmCGZ0roPJpnM2fm93OdMuhZQ/yzwpHGyPwEPfTXTT4zFhDvhBKt/WMPSWoPkVNqjjn3A85sm4/FNy7C/rRatnQF09XvNzcepI96cNsMkUir6TZ3eAt6kGRFnHMdeNKSKHYw6aaOz07xMI04kxqBOj9P3CeosLlBc5UtgGpGwkxe14PzTnsQpK3iV5T/U2iRksVYM3U+Ter3rWeC2+8/Axl1T0d7nxeCgB2F6+E6nqutnx9GqZP4+HKNN153Eq8/ehute9TjmrFYk68b/uQLrtkzBSQs6yt8kmEGTFY8lESXCYx+Hhof7jbVETiILQ33I44u1O2YOJSY/yRSioThqplRh2YWLsfjseaibWYtIX9Q0X/FAGNpzTNMffRMkQuAh0nBoazs23b0Fe5/Zjwi10eN30aRV5kgmNSa5MvRn0ucxmYHWaDHxoSsTyZqEla8+AXNPnmGSycHO8OgaLSZrRA7ZKTwVT2H/xhbse6YZrTvaDwcF8Gcz+WJtlN2pNWhEnPj7Y+eyqeUj8srkx8HmQm5nUkWbpqhv2EzI12OfqDmnzsSyixajcX4Don0R03Q7dI3/IH+cGqGeCajLLI10aEsbDmw+ZNYL5L/jn/trvKYmsZDkargm61nfDDxZc5o2F060JosHCi0oDq8iR9EDuCDeismJAZM8OWn1cNJXzueVHqFd/L4uRwC/9xPJ8s6khbRK3QsRKsTb8cpYO6bSfXqIkHDqCk5DkNQaK46eS9jsR3kzmEsc/b1djxmmWbSamlqhOBGY/c463OOfQ6cFOhXaHZrU5ZrE1dCkyn3YzDeT2r403ocpqX4igTHt8aHab5hfbWYbuf1xW+mVzh3SavWm7aa/VsJ8rYjCFdUJvK0hhtk1MXOjv6fDh592ubGZCIuffl9Lewu/j53UA/Y0n1dMssDXG6A9j0fxZNoH+b2pAt7jcGf4MH19U00CNzZGMblqWHqH43F0JjmshaK9+wARxUcHXFhP+/tLtLc2J23mn/C9eWxqj2VCZeivft0fx+MIA2n7YcI11OchzSkWEPlaRATr5VVJXFgbU+k40iNoEwtJsA48fKS30jRf2ruog1vn48ChJjz8/Fy0dwRMTVN9dQx+TxIux8QMAdZ0heghtXf74aLPXzq/E2edtAuXn/MC6pdx72utln0EYuXQhIzGxtPrgPufPgsPPbHALJw8uT6CIN0La6vsGZwfmXgl6aHtOFiLaXWDuPC8l7Bn6wxs3FuPmZMHiiMZaCUQOSIQrLVik+TURY2YdfJMzD51BqYun2KaDcP9UZX3hUgNm7d2P7UP+9YfQDORm95DA6idWkUEZmxEYch0yIWK+TXXZJy9agYWrJkLF2u0qC1HabTo2kxGOI1BdDCGHet2o5kJC7UhFkkgWOszNU/54gT8GZyLatKceiJaMzDzlBnUTzPMJLERIkxD7eR7MolV0GMSv33PH8ChbW3o2N1t9jNr3FibZxThqYFJ1gveqXi4ZrXu84nQZBlKC+TwKw0NEatXEBFaGO8wNUeDRDaS2jyYqceG8n3VpcLY56rH7d5pWECEZE3sEOqTIYTtdPCzu0xSktP6qbPk1xChYk3LC54pWOemk6Z3hnIs55JExlhNh5pgMrlKdKGOyOUpiR7MiffQPcUQod+Fqe0pVMaayFsMe7JwSogquuW31kXRTK//2O/CTDq0TyXSVCiX4lzJJLf5RbqXIH3DfmgXVCVwEhMZJlIxTWKchkmu4mEnbunxEKFy4rFBh6mJm0zvm0T377XIdQrH6FQG6YKHaF9mzeDJ3hTODSbwKiKEU4cc9kfSak00wbroFdcPGzFpRCIuhMNuk0w11oXh8yQPaxoK8rBthhmN19XvRxuRran1g7j20mdx/eUvwT6DNXDDNFomLSaZpEjWjvXA7+44D3c+ssjUss2eSidDV3Jc0X0OemjhmAttRDgDwTiaasMV429VbBoz1kT1dwyiqimA5RctwpJzFqJuZo1pFmx5qQ0v3LcNu57aq7Rek4PwEKlJ56KBoc9kvy0mWqxJmr50Mla8cgnmrZljapz6idTwe6rps1LRJHY8tQfbHtiJ/Zta4CDCxTmijqeZyhcRNfunLWRmU196zgIsOW+hqdGKDURN7RwnCeVagVse2oFtj+3GYF/EbKMv4MlbVKCVYHMha7KeYJKVV02WodIHsCmQTWzRg7g6vBszkr3op5/1E9EYL5VgAhQw4vCb2h6bmd+JUxFYbSpTRMswUx6w9mynexLuYu2ZZ5q6N76vbDRapgnTbRKzYGQPrgrvMckblzgK0e+K1cw3kZqfXQmHmdhztrM0idVI97WF7ovNe2+oTuDdk6KYxj5aTK6IUP2pw4vfErnaFKcDKJGqGa503n3HjiVbHCm6K2lDLU3GK6mNl1XHsNiXgnvIX274g/jCvRNLsF772muHXQSmyc5pN4rS5MUkp3/QgwPtQSyb24VLz1uPS07fhbolUKZDJle0h2zYADz81Grcdt8KRInFzp3WZ5oy04YQonIiWtHwkMamDisvXYbYYAIb//EiBrrCqJtWBSeRm7SFpq3hGi322Zq3ZjbmrJpBMss0ae7f0IzmDS3Ytm43nE46/REBtOvoxEL0TyyaQN+hAdTPqMHS8xdh5sppNAcMNK8/iJce2o4+ImGs2XN7nJb208RosvqxwTcd69gni52oLdVkDWmsiFgl+kxtzSsizVgcbyMi5CPxlCSZYLJVl46Y5scNnMjVMxVgrRY7yR9XozVkCnQpzV38EBGrg5ia6kUf9QNH+9mlyF3ZY4ijbNPO8B9pjGKeN4XfdHpxX9iB5W7DzDOWLOBQGCKDe5MO8ytHX672p0zCO1wR8oFf/3ViCdbrX/e60nrYNqXV6ur3obUjiKlNA7jigk244apN6OoEvvXri/HwM7NhI4Y9syk0bo2VoFSYlg3xUMzU2vBS4K/15q6xyuIz2QeqXxOt+atnmWkkdj2z3yR1VY1Bk+AUg4ltKNoz1BNGdVOV2V4miKaPWr77aQI0Wc97Z2AdF4m2KoXDUIkW1opFm3Ht4C40pgZM011/iRKro0mWjl+ivvKl49jtbsSdQxotNv+ltY+WqbHymBnVZ0Z24QIimFWmxspLBNMtxKoCMURi9hGJ4dxiU2mPneJUPlTFlPye2xJO23EoZTNJn2PYkvDs3/4oBCv7zcNAKOw2ne+Xzu1G/4AHrX0+zGrqz+hbJSgzGJjwoLIhjdZgd9hk/vlMvGnFwSQRV4p7l9tRNnNDkSytycJ4NVnGkYLCbDKLd+Dy8C7MSPQg5PBi0FaehCKti2xz/ikzQtM3hwZHPfWDT0VGxltxTXgPmohg9tLPoqKxEpQ4/nTLLUKwxrN59A264SY27fcmRGMlEFQQmGSxyetRji5kZ3MzJUGWawCnF2AfK9ZYRfbgmsh+1KcGzUg39rMqd0IxXKPlNFLY5mnCFmcNXhZtwaRUyHTgD9lEYyWobILlrOROY25Z7Vd1lYRcCQSVhVZnNZbHDqGh6zHcVrsKcNURyQqNEiU3FA3nNvNWIbIPVw7uxLRkr1mipZt9koCKIBVDTvo9JpkEZsd7sDjWbvqZtTmCukiHkCtBZcMpXSAQCCoVHY4qTE714U09T+B3wSWAb7Y6eZkmw+HEijVWftPXqCH0Il5GZGJyss/M19RGRK1SycQQ0eKowEEzDgyQBDQCgRAsgUBQ4WBi1OEIojodwwf7nsMz8XY8EVxGK2O1yrLO2iyOCuTX4V24imRqsh9hIhS9Dr/pjySaGoFAIARLIBAIjgHne2LTFmthVkZbMDfeg+e8k7HFO0slCQ1twcWxTixItJtZzluHaayEXAkEAiFYAoFAMAKGiFKnIwivkcCFg7txcqwdfUS85ia6Tef1LvqdaKwEAoEQLIFAIBgH0WIyxVoqzmA+KTlomhCPJWICQYmjnqQRKs32UFAop+bv4HOGdI8QLIFAIMgj0XIo53aBoHzwfhKuc8eVeb3H+T1nXt5L8juSm6S7hGAJBAKBQCAYHQ+RnJfhPazRWkzyRZJXklwAs5CcYHwHNYFAIBAIBOWMK7MgV8fiDC0CIVgCwf9n7zrArSqu7jyQDoKACFhogqioGOy9K4oFey8x9hbFGI1GNCagYkwUo7FFbBFsIIpd0GhEsYuASlMQLCCC9Pr+s/67Tt686y1nyrn3nMte3zef9+GZOXOm7Fl7z549AoFAIMiBfSzzNZamE4IlEAgEAoEgNzpb5lspTScESyAQCAQCQW50lCYQgiUQCAQCgcAfWih7C5ZACJZAIBAIBIIc6KQypwMFQrAEAoFAIBB4QldpAiFYAoFAIBAI/KKbNIEQLIFAIBAIBH4h/ldCsAQCgUAgEHhGd4e8C6X57FHOq3Jwg2q7IG0epI2DtGmQmgepjcrckdQkSLgIDBdQLlWZcP3fBenHIH0ZpKlBmqQyl1OuTnEfoA16B2lHToRGQVoQpIlBeixI78T4bjg+tg3SVuyHTvy7GVMdtvsStvMc1mtKkMazL8qBKpW5rLQJx1G19u+LWd+fOHZ8j9l1+d76quaS1BV8588lFEjop62DtF2QNgzSJqxbI7YH6rEoSN8GaRbnzCdBml0GoYn2ahWkHpzrXfh3a9a3EcdiNdsR6Qf2Ier9dZA+C9L3bGtBNECm7hqkXwVpoyC1p0yFPJ0XpJls1/coS5N2JQrWgi0pF7txzLfgOK+nMjGa8C3zOa6nc7x8ynG/KuX9h/Vw/yDtSfm8Lr/38yA9EaRXi+RvRPm0iUMdwguh9Us5q1mPUo+FbVXmGp9NtbHQlDxmOeXabKbxHNtTyykzSkmwQJqOCtJBQdqeDbaeY5mrKHQx4F4O0iNs3FIAC/w2nPg9uMi1Y5ticr8RpL8WyI/LNm8O0n4q9wkP/PvFnEQHeSSRqOOpLBOTdgPLcpayrd8P0uNBeroEbY62viFIOwVpfQqQXFhG8gdBe12Qxjm+93dBOpmLVAuV2/JbTWIMJeCZIF0Zw/fvHKTzScY7Wc7f+VxY3wzS/UH6MIZ61ufCcAwX9w05X1zxHRfRZ4P0HIVopaCDJk+6kYiGbTaVC+rwCOVgO+hSKm1dDN4PQvvfIN3oYb64KE6QTUewLTYikbIBlIovgjQiSMP4faU0HvRUGefyrfgdG3JezCGhvbEASWnHteFQkqxs7BGks6kw7UKFRAeitg+mjKxDZcYWD7OedbU+WkMii36aG6PyfwLf0ZNtUt9SZkB5eJD8oKTGmKrq6mqrjMcfe6yJFnV5kPqSVMWJ5VzssahOi6H8XkHqE6QD2OnFrhG4O0jn5vj3gznxowqPc4J0jwcBfnWQTlG5b1F3BSxbfwvSfTH1LQjpx5YCd/cgvWX53ouCdLtFvnspBH0AWjxutj88hnZ9mQvyRA9ldQzSWUH6NTXMuDGMffN2SklVby4gu1PZKYYjSN5zAfPiGs7xuo71ujNIF5S4La6krOwQQ9kgILcF6Y4YFfDNOD97kxwWMx48w/7Mtca8YmB8GMA+D9EqRtKTjTdJ9nyiEQ0LSO09lz2Dc+Rh04xDH388cQRrd06ag8sguMBSnwrSFSqzveCKJiRLJ1nkba1qb6WhTjcZljGbi5fNtQXt+L7jLDUAU3xJ7ekOz+XCGniZZd5RJMamaEiLj20MmS2oPdkCi+atQbow5j6DRnoDFRMbYEG5SmUsVuXw63yaC80HKSFW21Ce7GiYbxLHVDZOD1J/5Tda97tUxibH3BYDOG42LUG7L6WiirZa4KlMjPdBlrIJOx8TtL/PtFRQQUS+5e9LKTNKBRgaPvHUjtdROdsw5jq/R1L6StwEKy5h2C9I/ykTuVLU4MAAP/LEsA+1JFeKAyZEXwtyFU6g7S3ywdI2noKyfonavhsJ1msx9KkL4bbVplywiWP+90tArkI5gEXnNIu8GNMfk8CX69DMkWyrvikhWFdbkCtgc1pKdNwVpAeU/6tQdqQMjwuwcI4hMd+0RO2O+XyJyriU9PRU5tYOit/lWeXYWv97e5Q5ptjV01gASftjCciV4loKy/15pRCsvnF8kG5JiCCDmfUNCmAXzHfIe7jWqS5+Sl0Mn4cp9CXltv/ugn04aXb1VN6KMuRdrdycOW3fuzEJw9Yl7rMLLPr4aZUcoC6/SwHBmuUoXwEcQoFPybkxk6AHYigX/qXYkt6rTO2P7xrnqe1cDoyEBogNuE7ZQt9WrVfitnRdX07jWOhRhnFwJxXL1BAslPfXBAo0bBfu7JAfJ/nWOBIjV0G13OBZmKxvSEC7gyC8peLxq0gDqi3z4WBDrzLU14TEw9l1SALbHM7BZyR8XLzrkLcj/4t5dVIJ6nq6yhxY8AWQChMfo7gAIgLr3zmO5eAAwnTLvPBJhvsJ3ClalEn59NGOLmNrSJnHwnUq42ebCoKFxm6dUKEGa46t0xwsWJ9Z5oVZ+iGVcVR2wdcGA+byhLU9TidtrARRgC2TckVeNvFXrJOARTIf7lD2p2NLAZeTm5uRRG5d4vas8lAOjtmPSlhf/FNlTre74COHvHC47lPCeZsUJfIUFY911AY4KLNLGggWrCxJPToNk7qLdc32pFJzDiYXLIvYrtiy6Z/Atse+OhyQ6ypBIcBMPqCM7zdZKLB9OjGh7YjTvc8nuJ9xEGSGZV5Y4ku9DdpN/dL3yxQ4MPJaQvvjySDt4JD/LYe8fZX7qe6Pyth2NgRrMxodkoSn0kCwgBEJFmw4FruuZd7Py6zxLinyDEzMzyS47RGT5VrhUEU1qXJiuOHzjya4LRF/a/8E129iysbmzo754R+3XoK/726HvNPKWO8fs9amUm8XzrUcC0lD2ziME3EQrKEJnkTQFH5vmXd6Gev9UkQtrGnChTQIVi8lyAWE09i7jO+HhfE5wzw4LTozwW16YoLrNi1l4/MIh7zwc+qd8O/DqcJrLPOW8zoZzFn9lPTsEr/f1Ho3ROUONZIEXKfcXXliJ1i4RiXJVizb7bofy1jnYtYzsO99UyKo7xculRM7lvn9l1jkwfbAPxLcpvskuG5zUjY+t3PI+/uUfCMOBtkEw15axjq/nvX3EyV8N/ySPzZ4HuE4TkvBGPCGuK7KAYmBxSeKwzsc9BD4Cyf1cO0NHMr1O6SakEAcqDLxqFwBZ2sE+jMNjlaukxpYxIr5Ltzj6V0w9z5Ia8ZP/DccXOioMo6ge3p4B9oeoSueUQIdfTyUcQcFLvoRfntVnD/YnoXfw2Eqs3WWjX+rzEEEG+AkFnyCohzXhnY9VmV8RmZyruvzChZmHETZTWWuyXAFYgLBt2ZcAvs7LoXtEyq51fz+bZWfo/vtWZ6p7xiuvunk6duwO/Iqx1E1x3drKpe+Fm4cIDjdME8573B8Pcd6ivZAvMXu2hpqe0ghvAc45AowyqzmPDZtc5+Hr7BjM4qcAWMB/r24JgpW650cygXHgA/nEh+VjItg4ZJZxNQZluf/TyPTftZAsENTxr1O9yk3h0RglwQRLAxU+GPggADurMIW2oZZloVCwriTJ+I5lH02L8//H0ySO1K5By09UQjWL+C6dRrlOqDrKXzOJmFel5YUl4B7P5Mw53s3SNTDHDeI9RPlNoIwPs0tJIWucz2JBMu31QOn4e7OYVGAQnkpkys6WhCsmz1ZSn5NRTwXML5wldRDjosrYLMVujymMQJF91OW35rKUeesPv8qR77RKhN3EXdZNuBat76DseQVVXNAKSRYprEhcZr+LA9tgvslj1T5fRixTv2B48GWEyH8yb1JJljA4yRC/bR/e4id9aiyO30wngJzDBcUW3S3yOPzZvaZHAhg4dm+XXX5jTiGvVAVP21xtYf6oIwop9deogXqcZJdF2tNywJkbm0DhKBLrLB/qei+EO8wYV4ewLn0s2P9oSTh7jDdSX8E03DL8ieTuD2l3AIFd09on6/0VM40kqeRBWQNIo3DCv6c47tML+xG/7mGy4DFav+I4wWO+Dj6f7rD+5pTYX22DH2paDm5mXMnlxEAayq2a9eQYBVCKF9dLjie5UE+ABcpd5ckGGVOi6CcDGCf2JL7S9NAsIDLOUF6cMBM8VDmai4MCxwsKRuVUSCO5gReUuD73mSKohWc7lifp5RZaIDPqSXOU/Z39DWmljBYuNX/A1vgLiesnrTIgy3gYR6/AX05gZrzM8rfqdvjOddtry1qn9A+96WwQRn7PsJzozjXXWI+mRKs8x2/bR5lvQkQZLarcrtB4mJDguVrdwMGhENU4YMj45SZRbahI7Fp7unbXK/8gtvDsQbPD6IRxmZ3Z3Nyls9cP7oUd4e9qDKm/ikey1zmqI3ZCOtqD/VGBOd9laf9XZU5jeESW+pHZRcNeolyvw7pGOFV/4PrlmtSgrhCebhJ+Q1pAsVmuEP+pJ6s9RG485CI5CrEjSUep66nxY60lLuukbn3MlR4fPTlNypzb26ST+XaYlsPMurXFnlcdneO8vHhdVLcaS7RkG2uvXGdRAguuJPnNnC9sBQWRlv/AfjILHJ4N7SLtsKtvJD3yyu8fVzmeqUGt71CmQdTfV+5OdebbDVhy3sjh3dhx8P2fj4conjJ4d3rkLyWah1dSBIyv0LH6sGO+eHG8KxFPlgE51q+8xAfH55mgpU2wRnH8VTXU30jHYWt61UHuyuBIlF18ZPAlsifKrh91pQpb5xw2VYCSRpkmfebEn2f69x+0jG/q3P9HgbPYkfFxYXkXAcikAZs6JjfJXTCy5b5EA/LNcJ+qglWVcrqG0dgQRc/A5zCcHUyv88xfzclALDN4xoX6Y8qc/HscRXYPnUq8JtciJ/LYryyRN/nSrDedcw/2pFMmtxNt9yRML9f4fJtE4e8kGljHPK/aZkPfsIbuX54mgXXgpTVt7nn8hAQr7ND/jEe6oAjxC6Rg9dTAqDaEwHHeEC4DWytHFRB7VOJWycuCqJLXKtSWf5d/K9wstqHz67L3YdYXKMe4qnjuJa2VJUNF0X6A8d3u9zA4rxmr5PAzmhGxosBDsc43LGHGB6I2dNUExI91doN15D+//VUD5wcsz2p1U64VS3C6+tG9z2YPqMl4FFPhNo34DSN7U0c5e9IgdaW87yptnBtLcMjVcC6spnjXPABKBq2rhlYhxB7apZ0pxNaOxoC3nZ8/3sOedv5mAjlBgIswvl7e5KGLmLZiIQOjvl9XTb7k6OWKMgAp22v9lxmD6YzKWjgl/JkGb9xS8717TjvN1HucZIEyUNbZR/Y0qds+sohbx2V/Ltd0wDIeBeraehnbOMPhW3bTo51Tx3BAjHAEcjN2XhdZQyWnF3DZ8CXs6vL9k176cb/AX4Y8I+pF1P5UGAQqA+RvnEdEoKT/hzzN6F/EYm9J4nVNtLNawVc5/V0T/VY7JhfCJY7XBWovkzlUhRSQ7CgveK28mNVZTqtlhptHPLCodrXXWg/OOSFpbKBiu+qiTQBJ5FwWibu04A9mWAtg2VrZAzvgPKE63fOUe4xvgTpQyvH/N96qscix/ytpSudkeY2XNe1gFIQHWxR3K8y/iDHC7nyBhftyucVNS4nmnAJaXPpyv8BBGtCCQUfIq7f6rFMXEuDWwGwxXORkKu1Fq4Lk68DTK6XMItsckejFNe9iWsBcVuwcOHiH2SMJY5gLfZYDxch1kDZX7dTqdhFlfaELO7dCrftXYBYPndJ9wk8LEy+LsJ2vY6okXSlM+qluO7OW8RxWpPuEXIVK+okpN9dzPDVys8VRJUE+EWdXuJ34kqSmxzyDxJyJcia10lYl6rK/B0CD8E6ywjn+GRxESzErjhLxlZiCZZPweGioVSp9AWMLQXghA6n9CUlfCeuXjneIt8jqvKv6hGUdl2prpDvEJRWhvnEGh9KYxwDCEfBfyXjKna4bM35JDUuZnSxYBXWnuC/+FwJ3znA8PnfK7vLwgWVjdUJqUd1hXxHmrEmpfU+Srn78HknWEcH6XcypkoCFz+ddT3Wo7FD3sXKrz9YpQHH1Q8N0o4qsw23MOb3IWbMbyI+2ztIN0oXCXLANfK+r/AIrocsfpaudEYa2/BElbls3Bk+ndwR+faxGD4WdxEhZtOXJBVz2GmIjXHAWjxwXXyfcDVDlfJjPWrj+A0ixIpjHBNIFpzJT1bx3ePYX0W7Y/KWGN6NeT5ZZQJEIozIT1ysD1SZeFqCdMBVEWjhqR6uTurzpSudMS9l9R3gk8f4JFiXeCoPx9SHq8xR7w+D9EWe5+qu5QTrO4e8OKKPYIA+roFwidiMRVTM8NEB5eIGpiNUZise2lYXj+9A9OLdgvRWgWdgVdvC0xgeEqTPSSC/zDMeFgrBSt04dcHGHpV+F/wkXekM15hmkAswssR5GrE++3qUygRj9gafBOtMD2X0U9Hj8rRZyweuSyR2kNMOngiWS6yYmSJ/rDGC6VqVcU4fqDL3+fnAgUUI1u0e3nG9yvhrRnGCbSvdnSrMIFG2vSLF1+0ergRL3Bfc8bXKXFlju137zyA9kNaP9+WDtbujcEewyp7Kb9DDSsc0x/xbeaqHy1UI30g3esFQlblcF9t7PmIIFbJK7uA41xG1Hxaw61R6TxgJCgNba1855Pd1uffmDnlXKNki9AFYnyc75E/19Vq+CNYRjvn3C9InhnnWrOUDd6LjYrqvhzrUcxSGcxPextDC03LKEQsCrtn5lQfiUuiy9cMdy95HmZ+MXNvnehoxySHvXp7Wpv0c8s5T6fMfqsSx0C7NH+6LYLn4YzxiQa4AFyfvShDYOEI63iH/Hh7qAEHoYoafU6K2siVJi1X6YuHAn+kQR2JYKDigi+VzWJDeLvFcF5QHHzsS/F6O769P+WSLyUpCyPiCiyK9nRAspTZ1yDvYMt+hDu+sVyEDd4xDXmztdXJ8/8WO+d8rUTvZ+hoiwvm6KRwXrwfpVcfFKR9cHJCHWuY7WtaoVI5BF+zsmP8U5XZlzxjpQm/40iFvZ5XxCV1rCVZDVXhLoRimW+TByak9Hd7ZrEIG7ljH/Oc55MVpsz4O+WGVeLdE7WR77BuXlLsEZS2nBjzVIe9qS/JVDDZb2hhj+6W0D9ZmvKMy/na2+LXj+13jMb5WQX3hIsN87Pa87Jh/4NpMsEBWGpWwDjsF6VHHOleKT8d4x/wQQrbbu64nyRCKY2WJ2gnXzpheKv2g8hePpxyo65B3aUwEy5TsNPMw15soQTmw2JHkw7nZ9gqmY1Tm0IctED7kPxXUF9VlyhsCoZc+dci/bZD+uLYSLNf75LY1eBahGXxcHVK3QiYOThK6hjoYZZEHp0b7Or7334bPu5AxRIa+3uB5nMY71UP/2Ea5P1i5O5Nv6bg4xkGwWhs8i63Zccp9i7ZS3AHSiLcc8w+yGMdQpAY7vnd4BfUBDr+4xBps5KkerqEWcICnl8d2qUcZD0X6tCQTrDWOLPdvEQnPSWTCrTzUuX4FTaC/OubvSJIVNZ4VTPeu/glTgvSiYR7Xe6Fwb14xn7G2nHDXeeobmys/7md/IMbVO+xfU8FydpB2caj3jzER3WsjCmz4XODgS/cyklyBOwZ5KANbdTsZKOtwrt/A8Z23VVAfYH122ao921M9cDuE62GV9z3I5lNZl2mU9fh7iIrp2i8fBAtXnbiEC4AQHa3yx97BsXM4xz5iqAGvLQRrsHLf8oTFBI6IRxYhYreSALhaAG00xGUe2gqC85kgHacygVax+GIbcAdOsKnKj+UqhKmv3whV2/cEdxBeRsEC0nWyKrxtWY8C6G7Hek8qohHbAts2H6j88Yk2obB7UfkLmtpUVY7FOm2YQtnuApAl+JpeU4Asw2p1AceWKynHwvtFhfXDDw55+yj3w0yK5Op+D+X0p/J1lopm3W5Fhe0ulfH3BqlCUPSNcijgfXw3vI9I7hC4s5WbZWkPfjwWv8+oJTenFr5PDAOuQQVNHpCrP3hg4Nh+fUpl4mu9RUGzmgtUL8+D7xGLPN96evdhqubalfkkJXH56Zgc/sC1T4cXIcFIC0m4kGBpWqUyB016cB6191DvQtvwrvfMbc4x9gStDcu5cO7CNvAdFqMFBbFce1Ie4Aq18R7KuYELPQjbpxw3kOPdOG58xUu6vQL7YCqVSBfFFIfKxtE4sS0JCk6BX6ii72Ddx/HgCsRevCdIN6nMQalPOL9Xsn4NOS46sK5Rtzkhkzp7XGu8XZWDrTvXyOBY5E4s0YBDg/u67DgJuEn5M3FuofzcM5cPdyk7h8cPYqhL3E7sUa9zwlh8MuKzsIrtzRQHXlCF77n80lFYhziGKW40IdEVglUeQGF+Wfm5Nxa7HMcxxYFvVGVtD+qy8wTHMo5Uv9zhwOGhr1T0rWCMBRxaOcmjAnsQkw80JHE71FfD+9IW/5uyAddUVdY2IdA/BXVEwLnLLPN+odwuuC4Hot6hd7NKTuiQvxT5/2k8XbW231tabvwpJfU8qULbf3SMZZsqSWcnXNnprex8Z2MlWMNSNuBguWhZgULslYTXEVqUrS8VtkJHpKxPOkd4Bqb2yxNS3/9GUJaeSOHc6Cgcp+zj6pKE1/FeVVmhGXR8pNxCZhQCIq2bHCrANV77J7it4K95sa/CfBEsXHmSpsi3+O4OFTiR+ia4btgCe9WxjAfLVHfbk3OdI8yx3RPURzdEeAZ+ayNTNi+6CscpO+Db9HxC6/a9srespwX3x1Qu3BsONszzAQltUuHN39inQ+k9JW6EISqztWKLLSpwEiF+0W4JrBf23X3427xTYiIPHz3ESJltmR8O58Wcb5MSCBMHJV6K+OxFJa4b+txlm6m7EiQBOMTxWcLqNENl/Icr/b7Lu2Is+xCLPNgqvDWhbeUttItPgoVQClNK1ABr2EEui223Cp1IMMfvlaD64ITHyR7L+3MJ646TMw85kqBip2unJKCPsO1nch0FFqVRJawfNEoXq1lLJUgCcOIVMa2+TEh9oEDhGqY5a0Hbw/L875jK3tYyXz+VTLePp5JIsACEVFgQ88fD2RnXKKx0fNc2hs9XpWgyvRGkXVX547n8XWVOmvjEaJ8TIA8QngIWtzf5t4vWvX6EvnqujH0EoWtzKgv3WMbtrLqU43iJ4/yrNCf3qhS/F1b2HUowh6PISESJn5yA/qxTovecodyurCmkwNjGmoNby4UJmlsIKTIgqR2La1uOjPHjYZ3ZUVvwEIBurmVZpre1uwYrLPWpxbcpQMpxAAGa4W+DdKmK577Bo1UmDlQcQDw2xJTSwya4XJ3RLkJb4VhwOS6XxbbbScouXMlMkp+48DHH79v8G/1te4q0RwJJkssVJC5bGC6hSXydrlrAOVyuwx1DVMbKP8lTeXWVvytl4gRiVu4Wg0xerNyu4/mHylg2Pylz+zzDeqz2VWAczBkWBvitfO+xzK+DdAUHR7bVyuaqGCwo/QzzuIYIKIcZGgPleJWJXPtWCd63ksILEbvjjicDa6nPbSqMiTuD1DNIn2f9vwcthdJHGkEoBmxV3KLc75aMApAVREJ2De0xiQvVVx7rNktl4rptS7KrY6BlmYNU8jDbIa+LbJ3okNd3LDrIbsRze6hEbf4alZkzPJeL7bd5jutbqbCQ6+i7Hsv0cRHzu5S9IN3jykCswFmOUBlruTfEZZp8iFqj62mjeSRCXQoIyTsMFlAwZMT52VSZn6qYp+zjpJyj3K4rcMW/VOa0GiKYx7EdNY/904nCa3KJBEUfTgzX6OLPc7ziuo2f82jcVxoQaYz7Y1XmmqdpBvX4ncqcPAyvx/ENKAlXq8y27X2eysRWC/wZXQ+5zOcY6lKgrW83UHQmkuTjMMs1CSRYryq7k12QI6c4vPdMSzJwE/vaN17nHEZ07n8qP1di5VpAd6YSE4f8W0bZutgi70AqFaXEOFpq/uKhLKy/D3isG0g3dqkOV/H6eb5PWbgpiVUsJL+qutoumPnxxx4b9dFduHD14OJRzMw8nYsSnOaHRVw8cUwUJ5twVyGi06/gQglNbwKJFfaev/HQZrjq4xIKbkSSradqb7FU0dqBBQM+UINV+U2f2diCmhzikbRjinqtSzUXObTlFJKJUR5IjgvQ76erzH4+7rPbKIJAhKMtLEy4t2+sgTDBQhAGBV3EcfYFrTkfcZyt8PRdsOLsS3KMb4I/F5zmo24RraZ2jDn1LL91WYz9sB0J9q6sbzEHf4whxOd5gXWbH+EdsI7eyj5vwLmGPviJbT+e/52q0oGD2GYdOK7qql9u2eJaGLhCwEXiFg9zbX3KZFyt1FL98uowyLBVHN9TSVAeL1F7IKZSbyYsfgjWa3L901yS0K9psXpa/dISGhdQ1ys4b1txbcjVrj9T/jwQE2k1QVeOhd2oIEc5EAIrO6z8sPjH7aTegev73lS+2nC9iuqys4xK72yOCcSKfEv9cpeiIIY+bjf8S0GwdGD/H0emOwZpQ1VzVc8qLlJfqGQ4Ha5taExh1p5pPVX7GqWlJKvfUVjNUh73qX0rDSTBHSgwmmVZlyaTDM1NaV+14re15mLUIotwVdNCEV5aO6tM9WxEpWpjkt4GWv0mc4GZqCrnuipBPKhDxXwjjbQ3zFIiwgV0FpW+FdJs1uvAVpyzHbLWgPkkKNNUeU+BVnGN6kBCC2VhXVV7N24Rx8IPrKuzrE8LwRIIBAKBQCBIDWwJVh1pOoFAIBAIBAK/EIIlEAgEAoFAIARLIBAIBAKBQAiWQCAQCAQCgRAsgUAgEAgEAoEQLIFAIBAIBAIhWAKBQCAQCARCsAQCgUAgEAgEQrAEAoFAIBAIhGAJBAKBQCAQCMESCAQCgUAgEAjBEggEAoFAIBCCJRAIBAKBQCAESyAQCAQCgUAIlkAgEAgEAoFACJZAIBAIBAKBECyBQCAQCAQCIVgCgUAgEAgEAiFYAoFAIBAIBEKwBAKBQCAQCIRgCQQCgUAgEAiEYAkEAoFAIBAIwRIIBAKBQCAQgiUQCAQCgUAg0LCOY/5GQVovSHOCtNKyjAZBahmkuQ5lAO2C9FOQljmU0TZI31nkQ/3nObZlkyBtQtK7KkizgrTIQx83Y7nA8iDNCNIKh/KassxvHcfdBkGaHaTqiO+sCtJCi3e1CtKPCer/+vyeqM9XcY6syfHvy2OUDeifpUH62bGf62b1cRW/ZaWnetaP2IY+3xmiYY5+qeMog7LLqp/jHaoEY6Ed59uiEo2hOto6EOf8a0X5tzDGd5jKnULjC7K7HucQ1oQFMcq/fGPaZXzV5Xox38N4bMnf89kWvtAmSOvz99ee1t3/DWpbHMnKfMW0k0UZ+7OMsJwdLEneFOb/mmXaYAzzTwpSJ4PF72XmG2bxzk2DdEOQxpH4TAzSZ0H6nGW+HqT+HAAmaBGka4I0luV8xjSZ7xkVpN9Y1HdXrZ2nBWkrizJ2DNJ0loMyOhZ5/hBtjPQxJIKfMt/NEZ5/mHVCG21h8J7hfMdzHA+F0Jnfjuf7RSj7YO3b9TSDCWW9G6T7gnSYR4EzUnvXKZZlHKHVNVf9MWffCtLfgrSf5TseL/COXO+8ylP7bBOkLwu8C+PooyA9FqQTI5LAbJwU4Zv0sfCAp2/bkHMgnOdHWS5YE7S2OCaCDA+fv9TwXU8z32sR1rMrtHY7yeAdf+V3TNAW+UKK8nt8fohF20F2/4GyH/X8grJ7AvsZ830Q145ieIb1eJlEpxB+xTmZb3xBVr8dpJuCtH3Eb+luKO+yAT5wO9dkfR3D76lB+meQ9nIY65dSBs3Qysbvl4J0iY/JVFVdXW2V8fhjjx0Y/OdK7Z+wmO9iWMwnQdpa+/vMIP3LsIxDuSCEGMdF3BTLaClQJDibRySoq/l7ASdHVPwpSH+M+OwCCurnIzx7TpAGRBAEYVtdyokTBWcF6R7tbwjibobtPDNIG2l/70Nymw83kCwC1/LvqBrPbP5+I8JEhHDpwt/fkAxFsXgsJJlbHcHasD+FHfBkhIUHgv0yg7bFuL2cBNoWW1LQhJjNRdcUfzcUUs9zTrxrkGe5IXl5z1KJywaUk3sNnp9FWfmIQR4szqcZPL+Klg5X7ERZHgLjet0gLTEo48UgHaj93Z99mw+tVWYXJFRYjjR41wrtuxuowtb5Z7IUkfYqmiUe82ozbX5MLPBse8268r3KWMWj4vwg/VlldoWi4LdBui3imgYZtbjAsxcE6Q6DumIsn6oK70AcRTkHjAhSXwPDBYjVhRGfv5dyMqrlqT05Q68iz/03SLvjG4c+/rjVZHLZIvwp6++dg/RrA4J0bha5ChcrU/TLwXrba4trVGBrqIPGvG/hYhVFeG5o8L4mJBTbZxGdMSSci/nMNhyQIDDNI1h6FAflRdrf0B6e4sKynIIMA+ZkajQ7cBAdRU0wCpnQ0TVIR2uTqBiuzyJXKoLg1seZiZl5FcturAnvQvhBI1io450klMUwm30UxWStf2uUrRB9SwJa1YeaJoqFD+b8bTXy2J2WtAc4F23w+xzCCCR4tGE5P2ZZmqZqdV/DMb4d5UZorTuYQvUfEd8REuEF1GZVHitiFZWhp5Uf/Jw1d1/L+rZ6XIj35gIH+fAw510fjs1imJtFDCYWsELUpxLhA9nbm3UpQ3obEPQDcyiIhYCxvJSWrDmG9Z1F2fiDKu5ukF32GxEVxG81grUigtxZxrlpsgYNDdJx2t+YL89yzi9geZvToNBLI8O3FWmbzvzuaoMxPZYWNF3WNKKVaw/+G8ZyD9Yln1K5qEDb5wO2NN/MMnC8SvnzOb+jK+vRR1P8D+PaNjmC4j2Ra2qo8N9NK1kVv+lEjotOrpNpHeUXEIzDijDlkGTc5uF90A721BqqObWtXhYEK5f5cKBy30fPxl0auVpJbfihHM89Rq33bFrk7ixS7hlZ5Aqm3KtyTKz7SXQGq8z2m2KftbcQbuF7ohKsC1V68Btqk18npD6DC1imunHu7aeNhfc41kyAeXmsRl4akpSfb0GwdMBS+2We/7cP51loWbqDisHzBuV/p2pb00uJpzkH8mnKUNRO4N8H8u/fGr5joKFlzzcOUhlfoBkRnv1biuY4FurTld1Wnk8MyCJXFxWwJl1PknWGxTiKimEF1mco/U+QfPWkTL/d8/q4uUbsTuFamI1BJFVQJrFbswGVmGKuSrdo5Ooj8gfdcPAU2/hCGh+qXT7GxynC1VoFIZBvjZDnTmXnl5ANfYBdQy0GuMChzBVa2/xHFferMcF2qsan5SsOpIeK5MGW3JlFnqnSNHhFy9uVBQbHdLL/0RrRfsbgO/Sts84R+/xWFW3bstxYnqXhJuWkbfsC/w/kBduPl2URsg6G7zhY1WwpQCt8UROqTRzqXqgeo6lADNX+7TlqmlFRv4z90rrA/5tNbfh4Tcu/RJm7MGxcpm/TLa5RdiZOVrV9YJcmdI6vzjIKbFzGuqyvanwDUa99VfGtOli2sI36fYx1yofhqrZf5sEe3wtrdug28QOtSY8VeH4k19CZ/HtHTUHMhz00OX+gyr9rdgcJmBN8LB5Y3LGtMF4TzI0LPA8Sdip/f1BA+4vy3nALZwaJymJNU1zfstz7OYgAODtf7XEAXaf9hk/CVE/lHqwtMq+rjO9OFPTNGtw9Db8lNAHD2telwLNdVI3zKqxkjyaYYD2iTWoQg7tTpJHDevAKf9e1sOrspikZIFdvaXJi65jrfoJmIalS9odVkohhWePo5pTUG6T3Q/7Gwn94kefv034PVMV3MsoFLN6hRbCxqu3DW2roh41uVG6W4lKOi5B8N/NY7vVZbfF5xL78i/Z3IT5Rl/wDmKTsdmxKTrBQxguqxncDwvHJIsImxGWalmyK3TWLyMM5yr7YstzFJG6h9oUTHRt6aCdour01zXC4x37U/W3+YJAP++5/1/6O6gAMH5MhqmbrAxhU4Pl/a7+PSzjBgtUPW2LzNQHYPUWLuS6kcFKqgYEV6GT+foH/fUf7/2eXeLHpoyoLAzTLyR5ltppEBU6wnaH9/aDKb4U+Sxtr13Actk7od8GJ/EyNzECxvKBMddHb9+GUjOVq5d86CYPIfpqCZ7JG3K+RpY4qv/M66h3uvrQrRUP52v7YlEI5rDyIxKE5noNlKTzFAevHfxwWrz213+HJNt3nxHbCwEnzR1Vzcg3Ofc97aKM9tfZ+TbnHBVEaoQ3bAgL8U8P8D2q/tzXIh4GMrZzQEbtvHivHlhpxg9YAZ/5uCRYe3dk3+vbzKJUewG9gqqZdRj1SfaS2eIanSidoVojTNe0vLryiapxt91OVFQj5myzrRBosdN0pT8Lx3zwP0YaLge4jCotC0wR/V0NaRw7R/g3W38YlrgdkaFf+nk1Cmwa0UjUnHVd4KnNvVeOOA9eMHwzyrsoy6hyU5zls04dbgvDZ+lfcDeVLgIUWnlO1f8tlBr81S7sG2lq+8zRtYIZbC/O56Idayr4W5YZaJnxYwr3drTXCZYsttd/ve+zDTTjgFetrapafpA06k/hPG/C/+vHroUUI3MXaBE0qVmn1DgUe/MwGpWgx1xfyqFt7ekiFYVpbDMmjbcdJRML52yVinhUp6Rc9HInJXPuqjEQE0C3k8O9cN+u5B1TNgalQ2e2S8L6AlQOn/cJwG7DKP1viOvTQfr+boLYp5tjdX+MOMzy9Uz81+I5Ffr39Clmn/pwlz9DnfeJSHn0RrNXaAvuCpv3ohOswTajg5M3IrLwm2E+bwCMLkLi9HQYXrHF7af+O+EstHNpoE+23z5NpugPxdIv8yzWLR3uDfKHT7m0aEcEk0X3W+qkac+3HKnPcVicxSYQuXPbIWlg2SslCPkX7HaVPQcLC0zcvZI1P/VTYpSWo+6wcilsxtCZ5L5S2TEC/6D4lJj6i5xf5tqNjqm8om2FNeFhTjnRXDISTCbeWoaid63ltiQuhteQ8VRMSYx/l1+fWRHbPTFDbzC/AF65TtU+r3+rpnbqcmmyRf5r2u9CBnIez+rgPSRbWQGzjd/TZkL7CNOiLEo5kh75GMBuHp+R0J8+rDNhyLujH/e/JoSXOJxlCfCcXyxM6baBW3yeVfdRpnSEv8NiH+gmqnyzLCPfTG1n2OU6VjONvbK2FTofXZz2TNvzAxS3c/sAR3h1TUG99HNSN8Lx+RPyfWf8PgudTkrCuJAZxOofq8XiaR8zTShUP+/Ks8hvt3gbLDPtF17SLoU3M/QJ/2RNZ74OoOH2QJV/P1OTCmoTPkTUaicStA+GBDnwPrNWlsIr6kN1xAL6QO+cgpNtlGQqwe/GJp3c2yzNPomJRDvKcDwNoQLlEU+Lac52/gsaUu5TZNmVeRuobmHTDNSZ5BjWccCsQzmtfOlqCwtMsH6ncRylDHxJY0fZ1/B44jYf306GsP3smpJWA9zQNtzVJSC9NkwDR+iyl33aXNl7DqxuSDtPFLZwjMPfnOlGlb4/GTVKqDQSl/r0LmH7OkbBt/m6K59cSLsC5vm0Zx2fcIRHmqhpLlaKiCZ+9ozVl9ImUti/8Fm/RFOFXylCHJK0J3Wmc0NORGrnCeoht4/4J7c8ocgMyraPK+OE9l6X4XKcyu0HbJZFghQw4FPIIGRBGZsZ21DmOZet3Y92Y5xnd4fI8D9+jH0+GedFmq3CFhWYeBXrcpvUsywgtVy5CeqD2G8e1H8rSdNIM/eoOmMeTfgKshYHgbqtqrHL5YqE9omqOZcd9mlDXZKNeND2Twn8T9o2ewn/7SwL6Rb/KxsQ14rw83xam7srjBbUFMFRTNiDjX9L+36Upn+PXa/JvD1V7GywurMozZ8uN6ezbV5jg2vE65QCslIhw/oDnd+rxqGz8oZpYzC20Pw6w4UAe7tXV/YVx4AG7YU6HNeIiWDhZdqW26IdOkRcq99goe2vveINkpYWWmlMj+VYjZK4L4jhVO6bQCE1zjqpl65Hlffry6E6GHS3y42h1lxx1NAWc5QfwN5w3Q3+736vkbxcUw4Qsov50CeaQCzprv78r8qwenPRTCqoWWQmuBGGcO1jx4oyJpftiRA2kuDKPdQdpgUrO9ot+Qa/JKeLvSaByfd/cEls/fqt9S6jhw3I1MuVzfJGq7bN7u6o5VVg3pnfq8jZJShvcebANfADT/mwbuHng5N2yGN45K888sZF5NhwDOyynU76Fil1TjgPbmJqxLg6Ds/5eo2oHorMBmO2BGsPE/u83OdIXWVaivTx8z02atQhhEU4wbEPdCe9XngnWj9okNT1qvJlmNZjkWJerVe3782BZcA2qqAs3E7+IldrC4yMaP3yTQh8XLCwXq+Ri1yziWwh67KmBeebTHGp4Ic6Nse6hTwQsZpMtxkiSofu1mLhJNEvQN7xABVbHaY5lVmlydKVh3lWaHHad59hG1g913K+NxTgwOaY1wRWNy/BO/QCIzYXseuwrF98puLvoPqmIDN/btrA4CRZYbl9qvkiHeCgTVoT6GtnagCyziZbwd5usQeIr5swB2m9sgcHfKGo09jFZ5fgSmiARr/M3LA09DPPrzucfeKjP0dQG0OdHeChP3wJtYJAP46OR53GuX2ILp+rNPZBS34B1aRttDo4t8Cysu/q2MsZzi6z5FFq0GmeNmTi2NBCzK4zFNVqlJ/xCFKyfJQNfTvG3YI7DKXwiFQ1X/y8o3+G2jum1R401kubDUg6Le2jxxBVHhyl/N25kY4KmtHXKssKUE+VQWEZrCvE+XMNNeIx+RY5r3MoXNYMI1hDbUFLeL3vOxghVs53mA7rV4DIuIHXzkI41fAbmRpx+OVu5mzYRGBV79f3ZdjhtENVPZDoF0hYkV3AS9RXNfYiq8U3rb0BmIcz0+Ec+4nONybJ2uELfAoXZOqqT+Y4asfIVFgIHKi7VtNz+KnkhJ/StbGzbFPLN0S1R11LYr5NnPq3mHNqWSszOqiYkiy/8Q/udpuCuUXCBRvgnKLuj6EkBtp1391jeIipSjbm4RkVHVbOl/KOnubiShoFQab07RoK1mutjeOUb3vtXtXZiLknWvlyX+qro15SdpJGgmZ4MBQs18matoK+Tog7YXdX4GA1X0W5tx5bZVSRhOM14l4d6XKcyjvptuUCZaG9YkMOTNnD8hg/ZPA91eo7aPgbmwaxflMGJsBOh4+045eFyyxjwpva7N1OxhR0+f/qdVD5PBf2diyWI+3EqHn8EW5xArTvE9UWeD03xY6ksFAN8tMLtob08EywQ5+2ztMhKwb6qthN4PyXQAWIEH5wwuCxCJUQ5rX1nTHP8DRKdfpTzbWP89sEawbqWJOOjtXQcXKNqTjRfRRlQLGZkM1X7NOMVHuqBcDThThAMKNa+yWm6ikK/mPhvEfPop6Iu91gX/SSjSeyoJ6m9KnYgttJ2K5IHiw62E4rdEq6feoG/UCEfIWiK8C/QrzM6IqH9Ds1UP6EI82+hUAEbkSxuxr9BYO/1XCe9/xuWqB0KTXKMQcSDw52PoR8KCNPEAnkOUDWHT6Le+/W2ptmZnAYuJCQ7cV7o4xeWsq8MrQ7lHJ+FgH54VWtrfOtLhu+YqSofN2a12dVFxvu9qrZvzPWe64P1ohSXVY8noQsVww+pJBcCrhp7TaX/dHY2EME93PHqwPVxzwLP96LSFx7Sgk/20CLvwA4LTkDmO8lfxfU23Bl7SuU/XV0UabJghURkRpZVoxDgtDiF1gbsb++o/MTDeZuWjN9a5D2VkwM+LO34LY/x3yZxscCiDV+aY7QBhi1FWL/ynRi6hwMuPEZ/G0nZoxx40BKxtbOHqrHAhUB8m28T3PeIRYZQGVtoxHkUJxPM9zC1w38IUXkRn0X31YojbhMm9XVMpcIRJMb1OAaq+M3wt8KW8Abas89RGy4E/a7ODw3qMZbkrDnrFMUF4Axq5ZA3a/gNqC8ce49XtZ2Tb7QgxLB8nKi1Sy6hWZff+VkMcukYrV/C+mzFdtL9auBA+xuLd+DbNlG1wzzowL9PVjXx/9KIRzmOw8NDf6ZS/Shldii/dqf80q9DgTIZR5BVyJJhJfh2hIGB+0l428AoLvLDScBWsI83Y5uEijG2U7FTMauCSNb5lPPd2N+vkxC9SlmPOdaR6+L5Wr55qvbNMbmAtW8vbV14guR2OstFuJN+qmanbBHXHuvA4C4ES3dybRpzOX1UzfaBaTA7mHrDrcFrVO5LqJVGOKIeyYTJH86+4b16Ua+Z+ZCE79+qxmn+BE2w5EMUqx0EzzRNG9xV1T5Rlo3pzBPVvN40ywpmi+ZZ2mgU7EAiGvbfIaqwr9lMEsyo91q1yfpvMVzPSRqe/olyrYv+rVHuY2yp/f5NhMV5EcdlsdO6PTXiOUsVdoTPxm3auMW23kiV27lYr/uVEcr9gs+Z+GxuqM3ZKFa48cpPiAn9gEqxcagrCQMN3tEqi0BEObXq47SsbpFt7amcdQ2IJHxxLtIsFL0KPA/3jEsMCHnrPPXLh8eplOuhTIo54a+jld0uYr1ADrCj8bCqCeZ6gKp9qCoXni1iZWuvzY86BmO6pSey1MRQ3ikq+t0p64/TFLQzirQDTrIWC8fytaq5laIl1758lnhY6nFa/DuXBnAhWBP4cgjXrxzKmcRyVqv8zoSdqKHAumPq9/EoLU2YXIUc0rGthFNhJo7e0HDu4ML5lkE+bCvgRNrR1OB7sMNbUUiu5jNoF9zhh336qI578D16kkx8V1oK1me5K9mO2G7C/vaflJljKMjb92T7LjGzoG3jKO0yg3IWkxTAknUeLQPhKVJ823KW+T1J+GBl5h/1PonfOIM8F1IQNKGFplg8otkkfg3Yr8XwHoVCXVVzlD18Rx1+82J+80iO9Sia/KYcXystrHDPk5B15dxvmmdeoT1nqJrj83WyLEzLWPepLPMei3H0qqo5MRnF3cGXn85E1rtBjn4J59kStjG2Ax9R5veEjqWFok6Od+QiVuM8fdv3rGsT5eYs/APJez1l5iR+MZXPS7gQrq/JxVUkYN/RqnWDoRzCHN2F4y7qwtmP/bAx+7OYzyyUnE9Ibt4wbLNTqBydxzWhNb+9Lvt+HvsHayb8z8YUKQ9WMRxK+VzVPo2dC1PYlnWUv+tvplPe1VdmfmXVXBchz05XGWtwG5LAKrbxHM7DYZxfUfA15cVpJG+bso2ba+VizI7m2PrOtQFcCdajFLLTHMoZzwm1SuX31ZhIdr9GmZ/oWMgOaFNkURvBQWAyKd5m2U0iLpjZeJoDf2tOpNCah++czwH/kYWgm8p6TaNlLtRIQuI2k4uT6ambr9jn1crtFvVP2edLVM1Fq1HxDK1nXVXtcByh8J3NvjR1Pn+RwsvkJveJbOdmFHrFCNYPfL6RirZVPZ7tXTdH2RCEK7hYzOZCPsdA0DzIMsda9B++oRstCKuL1D0XMahi3RdSsI+xHEcjVE0A1Cj4j6eF42u2QcM837aa/TKHwtrmEvYP+I66EcZVlSrsb2eCeXxvU0OlMRtzOcfXUeahTDAH1+NiuIGqsXivYf1mc/6YKnljWe5CQ7mD9ujA/ix2anwZla52lgT1Dcq0rbn4t9SUkvmUURMizpkRbPupEWT9VPZXHeXPyX42ZUADQ7mqW6aqOA7aaBaxpew/zP3nLMp9gutuN667zbS+A8F6zQe5+v+JWV1dadfiCQQCgUAgEJQXQrAEAoFAIBAIhGAJBAKBQCAQCMESCAQCgUAgEIIlEAgEAoFAIBCCJRAIBAKBQCAESyAQCAQCgUAIlkAgEAgEAoFACJZAIBAIBAKBECyBQCAQCASCCsD/CTAA4Z1SroGAMdAAAAAASUVORK5CYII=`;

}
